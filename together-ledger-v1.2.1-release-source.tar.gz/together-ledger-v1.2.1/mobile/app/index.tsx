import { makeRedirectUri } from "expo-auth-session";
import * as Linking from "expo-linking";
import * as Crypto from "expo-crypto";
import * as WebBrowser from "expo-web-browser";
import * as Clipboard from "expo-clipboard";
import * as ImagePicker from "expo-image-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";
import DateTimePicker, { type DateTimePickerEvent } from "@react-native-community/datetimepicker";
import { encode as encodeBase64 } from "base-64";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import QRCode from "react-native-qrcode-svg";
import Svg, { Circle } from "react-native-svg";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Switch,
  Text as NativeTextComponent,
  TextInput,
  View,
  type TextProps,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  api,
  API_BASE_URL,
  clearSessionToken,
  getSessionToken,
  saveSessionToken,
} from "../lib/api";

const colors = {
  background: "#FBF7F3",
  surface: "#FFFCF9",
  ink: "#3A2F2B",
  muted: "#927E75",
  border: "#EEE1DA",
  rose: "#B56C78",
  roseSoft: "#F6E5E5",
  burgundy: "#5A3E43",
  sage: "#7E8D70",
  orange: "#C98558",
  blue: "#6D8EA8",
};

type AppearanceTheme =
  | "rose"
  | "graphite"
  | "latte"
  | "mint"
  | "ocean"
  | "sunset"
  | "starry"
  | "forest"
  | "lavender";
type AppearanceFont = "system" | "rounded" | "serif" | "clean" | "mono";
type AppearanceScale = "tiny" | "small" | "standard" | "large" | "xl";
type AppearanceCardStyle = "soft" | "outlined" | "flat";
type AppearanceNavStyle = "pill" | "line" | "minimal";
type AppearancePreferences = {
  theme: AppearanceTheme;
  font: AppearanceFont;
  scale: AppearanceScale;
  cardStyle: AppearanceCardStyle;
  navStyle: AppearanceNavStyle;
  compactMode: boolean;
  reduceMotion: boolean;
  autoReceiptNote: boolean;
};

const appearanceDefaults: AppearancePreferences = {
  theme: "rose",
  font: "system",
  scale: "standard",
  cardStyle: "soft",
  navStyle: "pill",
  compactMode: false,
  reduceMotion: false,
  autoReceiptNote: true,
};
const appearanceStorageKey = "together-ledger-appearance-v1";
const oauthStateKey = "together-ledger-oauth-state";
const appearancePalettes: Record<AppearanceTheme, typeof colors> = {
  rose: colors,
  graphite: {
    ...colors,
    background: "#F4F5F7",
    surface: "#FFFFFF",
    ink: "#252A31",
    muted: "#6B7280",
    border: "#E1E5EA",
    rose: "#58677A",
    roseSoft: "#E8EDF3",
    burgundy: "#303844",
  },
  latte: {
    ...colors,
    background: "#F8F1E8",
    surface: "#FFF9F1",
    ink: "#4A392E",
    muted: "#927765",
    border: "#E8D7C6",
    rose: "#B87955",
    roseSoft: "#F4E1D1",
    burgundy: "#684A3A",
  },
  mint: {
    ...colors,
    background: "#F0F7F4",
    surface: "#FBFFFD",
    ink: "#29443D",
    muted: "#6D8C82",
    border: "#D6E7E0",
    rose: "#4D9381",
    roseSoft: "#DDEFE8",
    burgundy: "#315F55",
    sage: "#5D8B72",
    orange: "#C88D62",
    blue: "#4E8990",
  },
  ocean: {
    ...colors,
    background: "#F2F7FB",
    surface: "#FCFEFF",
    ink: "#213747",
    muted: "#6A8291",
    border: "#D9E6EE",
    rose: "#397D9B",
    roseSoft: "#DDECF3",
    burgundy: "#294D61",
    sage: "#568B78",
    orange: "#C88A5F",
    blue: "#397D9B",
  },
  sunset: {
    ...colors,
    background: "#FFF7EF",
    surface: "#FFFCF7",
    ink: "#4B3029",
    muted: "#9A7468",
    border: "#F0DCCB",
    rose: "#D17B61",
    roseSoft: "#FBE4D9",
    burgundy: "#75473B",
    sage: "#7C946D",
    orange: "#D17B61",
    blue: "#758BA4",
  },
  starry: {
    ...colors,
    background: "#EEF1FA",
    surface: "#FBFCFF",
    ink: "#252B48",
    muted: "#707895",
    border: "#DDE2F2",
    rose: "#6D63B8",
    roseSoft: "#E8E6FA",
    burgundy: "#34345C",
    sage: "#6B9A9A",
    orange: "#C58B62",
    blue: "#5E78B5",
  },
  forest: {
    ...colors,
    background: "#F1F7F0",
    surface: "#FCFFFB",
    ink: "#294233",
    muted: "#6F8874",
    border: "#D8E8D7",
    rose: "#5A956F",
    roseSoft: "#E0F0E1",
    burgundy: "#365C46",
    sage: "#5C9568",
    orange: "#C38C5C",
    blue: "#568A92",
  },
  lavender: {
    ...colors,
    background: "#F7F1FB",
    surface: "#FFFCFF",
    ink: "#43354E",
    muted: "#887A93",
    border: "#E9DDF0",
    rose: "#9C6BB3",
    roseSoft: "#F0E3F6",
    burgundy: "#64456F",
    sage: "#79A08A",
    orange: "#C9906B",
    blue: "#7184B1",
  },
};

const appearanceScaleMap: Record<AppearanceScale, number> = {
  tiny: 0.82,
  small: 0.9,
  standard: 1,
  large: 1.12,
  xl: 1.25,
};
const appearanceFontMap: Record<AppearanceFont, string> = {
  system: Platform.select({ android: "sans-serif", ios: "System" }) || "sans-serif",
  rounded:
    Platform.select({ android: "sans-serif-rounded", ios: "System" }) ||
    "sans-serif",
  serif: Platform.select({ android: "serif", ios: "Times New Roman" }) || "serif",
  clean: Platform.select({ android: "sans-serif-condensed", ios: "System" }) || "sans-serif",
  mono: Platform.select({ android: "monospace", ios: "Menlo" }) || "monospace",
};

type AppearanceContextValue = {
  preferences: AppearancePreferences;
  palette: typeof colors;
  updatePreferences: (patch: Partial<AppearancePreferences>) => void;
};
const AppearanceContext = createContext<AppearanceContextValue>({
  preferences: appearanceDefaults,
  palette: colors,
  updatePreferences: () => undefined,
});

function AppearanceProvider({ children }: { children: ReactNode }) {
  const [preferences, setPreferences] = useState<AppearancePreferences>(
    appearanceDefaults
  );
  useEffect(() => {
    AsyncStorage.getItem(appearanceStorageKey).then(value => {
      if (!value) return;
      try {
        const saved = JSON.parse(value) as Partial<AppearancePreferences>;
        setPreferences({ ...appearanceDefaults, ...saved });
      } catch {
        // Ignore malformed local preferences and keep the defaults.
      }
    });
  }, []);
  const updatePreferences = useCallback(
    (patch: Partial<AppearancePreferences>) => {
      setPreferences(current => {
        const next = { ...current, ...patch };
        void AsyncStorage.setItem(appearanceStorageKey, JSON.stringify(next));
        return next;
      });
    },
    []
  );
  const value = useMemo(
    () => ({
      preferences,
      palette: appearancePalettes[preferences.theme],
      updatePreferences,
    }),
    [preferences, updatePreferences]
  );
  styles = createStyles(value.palette, preferences);
  return (
    <AppearanceContext.Provider value={value}>
      <View style={{ flex: 1, backgroundColor: value.palette.background }}>
        <ThemeAtmosphere theme={preferences.theme} palette={value.palette} />
        <View style={{ flex: 1 }}>{children}</View>
      </View>
    </AppearanceContext.Provider>
  );
}
function useAppearance() {
  return useContext(AppearanceContext);
}

function ThemeAtmosphere({
  theme,
  palette,
}: {
  theme: AppearanceTheme;
  palette: typeof colors;
}) {
  if (theme === "starry") {
    const stars = [
      ["7%", "8%", 3], ["23%", "16%", 2], ["47%", "7%", 4], ["73%", "14%", 2],
      ["89%", "5%", 3], ["15%", "33%", 2], ["62%", "27%", 3], ["94%", "38%", 2],
      ["36%", "52%", 2], ["80%", "59%", 3], ["6%", "70%", 2], ["56%", "84%", 3],
    ] as const;
    return (
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        <View style={{ position: "absolute", top: -120, right: -80, width: 280, height: 280, borderRadius: 140, backgroundColor: palette.roseSoft, opacity: 0.62 }} />
        {stars.map(([left, top, size], index) => (
          <View key={index} style={{ position: "absolute", left, top, width: size, height: size, borderRadius: size, backgroundColor: "#FFFFFF", opacity: index % 3 === 0 ? 0.92 : 0.56 }} />
        ))}
        <MaterialCommunityIcons name="star-four-points" size={28} color="#FFFFFF" style={{ position: "absolute", top: "20%", right: "13%", opacity: 0.7 }} />
        <MaterialCommunityIcons name="star-four-points-outline" size={18} color={palette.rose} style={{ position: "absolute", bottom: "19%", left: "10%", opacity: 0.55 }} />
      </View>
    );
  }
  if (theme === "forest") {
    return (
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        <View style={{ position: "absolute", left: -50, right: -50, bottom: 74, height: 150, borderTopLeftRadius: 180, borderTopRightRadius: 180, backgroundColor: "#C7E0CB", opacity: 0.75 }} />
        <View style={{ position: "absolute", left: -40, right: -40, bottom: -70, height: 184, borderRadius: 180, backgroundColor: "#A7D2CF", opacity: 0.56 }} />
        <MaterialCommunityIcons name="pine-tree" size={102} color="#5F9572" style={{ position: "absolute", bottom: 85, left: -7, opacity: 0.36 }} />
        <MaterialCommunityIcons name="pine-tree" size={74} color="#467A59" style={{ position: "absolute", bottom: 82, right: 9, opacity: 0.34 }} />
        <MaterialCommunityIcons name="pine-tree" size={55} color="#6DA277" style={{ position: "absolute", bottom: 99, right: 76, opacity: 0.28 }} />
      </View>
    );
  }
  if (theme === "ocean") {
    return (
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        <View style={{ position: "absolute", left: -80, right: -80, bottom: -130, height: 280, borderRadius: 220, backgroundColor: "#B9DCE9", opacity: 0.5 }} />
        <View style={{ position: "absolute", left: -100, right: -100, bottom: -180, height: 280, borderRadius: 240, backgroundColor: "#8DC7DB", opacity: 0.32 }} />
      </View>
    );
  }
  return null;
}

function AppText({ style, ...props }: TextProps) {
  const { preferences } = useAppearance();
  const flattened = StyleSheet.flatten(style) || {};
  const baseSize = typeof flattened.fontSize === "number" ? flattened.fontSize : 14;
  const baseLineHeight =
    typeof flattened.lineHeight === "number" ? flattened.lineHeight : undefined;
  const scale = appearanceScaleMap[preferences.scale];
  return (
    <NativeTextComponent
      {...props}
      style={[
        style,
        {
          fontSize: baseSize * scale,
          ...(baseLineHeight ? { lineHeight: baseLineHeight * scale } : {}),
          fontFamily: appearanceFontMap[preferences.font],
        },
      ]}
    />
    );
}
const Text = AppText;

type DrawerAction =
  | "overview"
  | "calendar"
  | "analysis"
  | "planning"
  | "settings";
type ConfirmOption = {
  label: string;
  onPress: () => void | Promise<void>;
  destructive?: boolean;
  icon?: string;
};
type ConfirmRequest = {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  destructive?: boolean;
  onConfirm?: () => void | Promise<void>;
  options?: ConfirmOption[];
};
type User = { id: number; name: string | null; email: string | null };
type Ledger = { id: number; name: string; type: string; inviteCode: string };
type LedgerMember = {
  member: { userId: number; role: "admin" | "member" | "viewer" };
  user: { id: number; name: string | null; email: string | null };
};
type Category = {
  id: number;
  parentCategoryId: number;
  name: string;
  type: "expense" | "income";
  icon: string;
  color: string;
  isActive?: number;
};
type PaymentMethod = { id: number; name: string; icon: string; isActive?: number };
type ActivityLog = {
  log: {
    id: number;
    action: "create" | "update" | "delete";
    entityType: "transaction" | "category" | "paymentMethod";
    entityId: number;
    summary: string;
    metadata: string | null;
    createdAt: Date | string;
  };
  user: { id: number; name: string | null; email: string | null };
};
type Transaction = {
  id: number;
  amount: number;
  type: "expense" | "income" | "transfer";
  payerId: number;
  categoryId: number;
  paymentMethodId: number;
  date: Date | string;
  note: string | null;
  splitType: "equal" | "custom" | "amount" | "none";
};
type Analytics = {
  income: number;
  expense: number;
  balance: number;
  categories: { id: number; name: string; color: string; amount: number }[];
};
type Settlement = {
  balances: { userId: number; net: number }[];
  settlement: { fromUserId: number; toUserId: number; amount: number } | null;
};
type SettlementHistory = {
  id: number;
  month: string;
  fromUserId: number;
  toUserId: number;
  amount: number;
  status: string;
  settledAt: Date | string;
};
type Budget = { id: number; categoryId: number; amount: number; month: string };
type TravelPlan = {
  id: number;
  ledgerId: number;
  createdBy: number;
  name: string;
  budget: number;
  startDate: Date | string;
  endDate: Date | string;
  notes: string | null;
};
type Recurring = {
  id: number;
  title: string;
  amount: number;
  type: "expense" | "income";
  categoryId: number;
  paymentMethodId: number;
  frequency: "weekly" | "monthly" | "yearly";
  dayOfMonth: number;
  isActive: number;
};

const APP_ID = process.env.EXPO_PUBLIC_APP_ID || "HDBmsjkFmtXoV2nyYfgboo";
const OAUTH_PORTAL_URL = (
  process.env.EXPO_PUBLIC_OAUTH_PORTAL_URL || "https://manus.im"
).replace(/\/$/, "");
const money = (value: number) =>
  `NT$ ${Math.round(value || 0).toLocaleString("zh-TW")}`;
const dateKeyPattern = /^(\d{4})-(\d{2})-(\d{2})$/;
const isValidDateKey = (value: string) => {
  const match = dateKeyPattern.exec(value);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const candidate = new Date(year, month - 1, day);
  return candidate.getFullYear() === year && candidate.getMonth() === month - 1 && candidate.getDate() === day;
};
const localDateFromKey = (value: string, endOfDay = false) => {
  const match = dateKeyPattern.exec(value);
  if (!match) return new Date(NaN);
  return new Date(
    Number(match[1]),
    Number(match[2]) - 1,
    Number(match[3]),
    endOfDay ? 23 : 0,
    endOfDay ? 59 : 0,
    endOfDay ? 59 : 0,
  );
};
const dateKey = (date: Date | string) => {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
const categorySystemIcon = (
  item: Pick<Category, "name" | "icon">
): keyof typeof MaterialCommunityIcons.glyphMap => {
  const name = `${item.name} ${item.icon}`.toLowerCase();
  if (/餐|飲|咖啡|食/.test(name)) return "food-outline";
  if (/交|車|油|停/.test(name)) return "car-outline";
  if (/住|房|水|電|生活|日用/.test(name)) return "home-heart";
  if (/購|衣|3c|娛樂|遊戲/.test(name)) return "shopping-outline";
  if (/旅|出遊/.test(name)) return "airplane";
  if (/禮|約|情侶|紀念/.test(name)) return "heart-outline";
  if (/薪|收入|獎金/.test(name)) return "cash-plus";
  return "tag-outline";
};
const paymentSystemIcon = (
  item: Pick<PaymentMethod, "name" | "icon">
): keyof typeof MaterialCommunityIcons.glyphMap => {
  const name = `${item.name} ${item.icon}`.toLowerCase();
  if (/現金/.test(name)) return "cash";
  if (/信用|卡/.test(name)) return "credit-card-outline";
  if (/電子|line|街口|pay/.test(name)) return "cellphone-nfc";
  if (/銀行|轉帳/.test(name)) return "bank-transfer";
  return "wallet-outline";
};
const currentMonth = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
};
const previousMonth = () => {
  const d = new Date();
  d.setMonth(d.getMonth() - 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
};
const monthLabel = (month: string) => month.replace("-", " / ");
const actionLabel = (action: DrawerAction) =>
  ({
    overview: "總覽",
    calendar: "月曆",
    analysis: "分析",
    planning: "規劃",
    settings: "設定",
  })[action];
const isLedgerAccessError = (error: unknown) => {
  const message = error instanceof Error ? error.message : String(error || "");
  return /FORBIDDEN|not a member|你不是此帳本的成員|找不到帳本/i.test(message);
};
const inviteCodeFromUrl = (url: string | null) => {
  if (!url) return "";
  const parsed = Linking.parse(url);
  const path = String(parsed.path || "").replace(/^\/+|\/+$/g, "");
  if (path !== "join" && path !== "invite") return "";
  const rawCode = parsed.queryParams?.code;
  const code = Array.isArray(rawCode) ? rawCode[0] : rawCode;
  return typeof code === "string" ? code.trim().toUpperCase() : "";
};

async function loginWithManus(mode: "signIn" | "signUp" = "signIn") {
  const appRedirectUri = makeRedirectUri({
    scheme: "togetherledger",
    path: "oauth/callback",
  });
  const webRedirectUri = "https://togetherapp-hdbmsjkf.manus.space/api/oauth/callback";
  const nonce = Crypto.randomUUID();
  const state = encodeBase64(JSON.stringify({ redirectUri: appRedirectUri, nonce }));
  const url = new URL(`${OAUTH_PORTAL_URL}/app-auth`);
  url.searchParams.set("appId", APP_ID);
  url.searchParams.set("redirectUri", webRedirectUri);
  url.searchParams.set("state", state);
  url.searchParams.set("type", mode);
  await AsyncStorage.setItem(oauthStateKey, state);
  const result = await WebBrowser.openAuthSessionAsync(
    url.toString(),
    appRedirectUri
  );
  if (result.type !== "success") {
    await AsyncStorage.removeItem(oauthStateKey);
    throw new Error("登入已取消。");
  }
  const callback = new URL(result.url);
  if (callback.searchParams.get("state") !== state)
    throw new Error("登入回呼驗證失敗，請重新嘗試。");
  const token = callback.searchParams.get("token");
  if (!token) throw new Error("登入完成，但沒有收到 session token。");
  await saveSessionToken(token);
  await AsyncStorage.removeItem(oauthStateKey);
  return api.auth.me.query();
}

export default function IndexScreen() {
  return (
    <AppearanceProvider>
      <AppContent />
    </AppearanceProvider>
  );
}

function AppContent() {
  const { palette } = useAppearance();
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [ledgers, setLedgers] = useState<Ledger[]>([]);
  const [activeLedger, setActiveLedger] = useState<Ledger | null>(null);
  const [members, setMembers] = useState<LedgerMember[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [calendarTransactions, setCalendarTransactions] = useState<
    Transaction[]
  >([]);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [previousAnalytics, setPreviousAnalytics] = useState<Analytics | null>(
    null
  );
  const [settlement, setSettlement] = useState<Settlement | null>(null);
  const [settlementHistory, setSettlementHistory] = useState<SettlementHistory[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [travelPlans, setTravelPlans] = useState<TravelPlan[]>([]);
  const [recurring, setRecurring] = useState<Recurring[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [ledgerModal, setLedgerModal] = useState<"create" | "join" | null>(
    null
  );
  const [transactionModal, setTransactionModal] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [budgetModal, setBudgetModal] = useState(false);
  const [travelPlanModal, setTravelPlanModal] = useState(false);
  const [recurringModal, setRecurringModal] = useState(false);
  const [settingsModal, setSettingsModal] = useState<
    "category" | "payment" | null
  >(null);
  const [ledgerManageModal, setLedgerManageModal] = useState<"rename" | "transfer" | null>(null);
  const [travelPlanName, setTravelPlanName] = useState("");
  const [travelPlanBudget, setTravelPlanBudget] = useState("");
  const [travelPlanStartDate, setTravelPlanStartDate] = useState("");
  const [travelPlanEndDate, setTravelPlanEndDate] = useState("");
  const [travelPlanNotes, setTravelPlanNotes] = useState("");
  const [ledgerName, setLedgerName] = useState("");
  const [inviteCode, setInviteCode] = useState("");
  const [pendingInviteCode, setPendingInviteCode] = useState("");
  const [ledgerType, setLedgerType] = useState<"couple" | "roommate" | "family">("couple");
  const [activeAction, setActiveAction] = useState<DrawerAction>("overview");
  const [ledgerHome, setLedgerHome] = useState(false);
  const [homePage, setHomePage] = useState<"ledgers" | "profile">("ledgers");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [confirmRequest, setConfirmRequest] = useState<ConfirmRequest | null>(null);
  const ledgerRequestRef = useRef(0);

  const syncLedgerList = useCallback(async (excludedLedgerId?: number) => {
    const rows = (await api.ledger.list.query()) as Array<{ ledger: Ledger }>;
    const nextLedgers = rows
      .map(row => row.ledger)
      .filter(ledger => ledger.id !== excludedLedgerId);
    setLedgers(nextLedgers);
    return nextLedgers;
  }, []);

  const reloadLedger = useCallback(async (ledgerId: number, requestId = ledgerRequestRef.current) => {
    const month = currentMonth();
    const [
      ,
      nextMembers,
      nextCategories,
      nextPayments,
      nextTransactions,
      nextCalendar,
      nextAnalytics,
      nextPreviousAnalytics,
      nextSettlement,
      nextHistory,
      nextBudgets,
      nextTravelPlans,
      nextRecurring,
      nextActivityLogs,
    ] = await Promise.all([
      api.ledger.syncRecurring.mutate({ ledgerId }).catch(() => undefined),
      api.ledger.members.query({ ledgerId }),
      api.ledger.categories.query({ ledgerId }),
      api.ledger.paymentMethods.query({ ledgerId }),
      api.ledger.transactions.query({ ledgerId, limit: 80 }),
      api.ledger.calendar.query({ ledgerId, month }),
      api.ledger.analytics.query({ ledgerId, month }),
      api.ledger.analytics.query({ ledgerId, month: previousMonth() }),
      api.ledger.settlement.summary.query({ ledgerId }),
      api.ledger.settlement.history.query({ ledgerId }),
      api.ledger.budgets.query({ ledgerId, month }),
      api.ledger.travelPlans.query({ ledgerId }),
      api.ledger.recurring.query({ ledgerId }),
      api.ledger.activityLogs.query({ ledgerId, limit: 40 }),
    ]);
    // The user can leave, delete, or switch a ledger while requests are in flight.
    // Ignore those older responses so they cannot repopulate a workspace just cleared.
    if (requestId !== ledgerRequestRef.current) return false;
    setMembers(nextMembers as LedgerMember[]);
    setCategories(nextCategories as Category[]);
    setPaymentMethods(nextPayments as PaymentMethod[]);
    setTransactions(nextTransactions as Transaction[]);
    setCalendarTransactions(nextCalendar as Transaction[]);
    setAnalytics(nextAnalytics as Analytics);
    setPreviousAnalytics(nextPreviousAnalytics as Analytics);
    setSettlement(nextSettlement as Settlement);
    setSettlementHistory(nextHistory as SettlementHistory[]);
    setBudgets(nextBudgets as Budget[]);
    setTravelPlans(nextTravelPlans as TravelPlan[]);
    setRecurring(nextRecurring as Recurring[]);
    setActivityLogs(nextActivityLogs as ActivityLog[]);
    return true;
  }, []);

  const loadWorkspace = useCallback(async () => {
    setBusy(true);
    try {
      const nextUser = await api.auth.me.query();
      if (!nextUser) {
        await clearSessionToken();
        setUser(null);
        setLedgers([]);
        setActiveLedger(null);
        return;
      }
      setUser(nextUser as User);
      ledgerRequestRef.current += 1;
      const nextLedgers = await syncLedgerList();
      // Never restore the last open ledger after a cold start. The app always opens at the ledger home.
      setLedgerHome(true);
      setHomePage("ledgers");
      setActiveLedger(null);
      if (nextLedgers.length === 0) {
        setMembers([]);
        setCategories([]);
        setPaymentMethods([]);
        setTransactions([]);
        setCalendarTransactions([]);
        setAnalytics(null);
        setPreviousAnalytics(null);
        setSettlement(null);
        setSettlementHistory([]);
        setBudgets([]);
        setTravelPlans([]);
        setRecurring([]);
        setActivityLogs([]);
      }
    } catch (loadError) {
      const message =
        loadError instanceof Error ? loadError.message : "無法載入帳本資料。";
      setError(message);
      if (
        String(message).includes("UNAUTHORIZED") ||
        String(message).includes("Unauthorized")
      ) {
        await clearSessionToken();
        setUser(null);
      }
    } finally {
      setBusy(false);
      setReady(true);
    }
  }, [syncLedgerList]);

  useEffect(() => {
    getSessionToken().then(token => {
      if (token) void loadWorkspace();
      else setReady(true);
    });
  }, [loadWorkspace]);
  useEffect(() => {
    let mounted = true;
    const receiveInvite = (url: string | null) => {
      const code = inviteCodeFromUrl(url);
      if (mounted && code) setPendingInviteCode(code);
    };
    void Linking.getInitialURL().then(receiveInvite);
    const subscription = Linking.addEventListener("url", event => {
      receiveInvite(event.url);
    });
    return () => {
      mounted = false;
      subscription.remove();
    };
  }, []);
  useEffect(() => {
    if (!ready || !user || !pendingInviteCode || ledgerModal) return;
    setInviteCode(pendingInviteCode);
    setPendingInviteCode("");
    setError("");
    setLedgerModal("join");
  }, [ready, user, pendingInviteCode, ledgerModal]);

  const selectLedger = async (ledger: Ledger) => {
    const requestId = ++ledgerRequestRef.current;
    setLedgerHome(false);
    setActiveLedger(ledger);
    setBusy(true);
    try {
      const applied = await reloadLedger(ledger.id, requestId);
      if (!applied) return;
      setError("");
    } catch (selectionError) {
      if (isLedgerAccessError(selectionError)) {
        await syncLedgerList(ledger.id);
        clearLedgerWorkspace();
        setLedgerHome(true);
        setHomePage("ledgers");
        setError("此帳本的存取權限已變更，已從清單移除。");
        return;
      }
      setError(
        selectionError instanceof Error
          ? selectionError.message
          : "切換帳本失敗。"
      );
    } finally {
      setBusy(false);
    }
  };

  const clearLedgerWorkspace = () => {
    ledgerRequestRef.current += 1;
    setActiveLedger(null);
    setMembers([]);
    setCategories([]);
    setPaymentMethods([]);
    setTransactions([]);
    setCalendarTransactions([]);
    setAnalytics(null);
    setPreviousAnalytics(null);
    setSettlement(null);
    setSettlementHistory([]);
    setBudgets([]);
    setTravelPlans([]);
    setRecurring([]);
    setActivityLogs([]);
  };
  const leaveLedger = () => {
    clearLedgerWorkspace();
    setLedgerHome(true);
    setHomePage("ledgers");
    setError("");
  };
  const updateLedgerName = async (name: string) => {
    if (!activeLedger) return;
    const trimmed = name.trim();
    if (!trimmed) {
      setError("帳本名稱不能是空白。");
      return;
    }
    setBusy(true);
    try {
      await api.ledger.rename.mutate({ ledgerId: activeLedger.id, name: trimmed });
      const nextLedger = { ...activeLedger, name: trimmed };
      setActiveLedger(nextLedger);
      setLedgers(current => current.map(item => item.id === nextLedger.id ? nextLedger : item));
      setLedgerManageModal(null);
      setError("");
    } catch (renameError) {
      setError(renameError instanceof Error ? renameError.message : "帳本名稱更新失敗。");
    } finally {
      setBusy(false);
    }
  };
  const transferOwnership = async (targetUserId: number) => {
    if (!activeLedger) return;
    setBusy(true);
    try {
      await api.ledger.transferOwnership.mutate({ ledgerId: activeLedger.id, targetUserId });
      await refresh();
      setLedgerManageModal(null);
    } catch (transferError) {
      setError(transferError instanceof Error ? transferError.message : "帳本所有權轉讓失敗。");
    } finally {
      setBusy(false);
    }
  };
  const createTravelPlan = async () => {
    if (!activeLedger) return;
    const budget = Number(travelPlanBudget);
    if (!travelPlanName.trim() || !Number.isInteger(budget) || budget <= 0) {
      setError("請輸入出遊名稱與正整數預算。");
      return;
    }
    if (!isValidDateKey(travelPlanStartDate) || !isValidDateKey(travelPlanEndDate) || travelPlanStartDate > travelPlanEndDate) {
      setError("請輸入有效的日期範圍（YYYY-MM-DD）。");
      return;
    }
    setBusy(true);
    try {
      await api.ledger.createTravelPlan.mutate({
        ledgerId: activeLedger.id,
        name: travelPlanName.trim(),
        budget,
        startDate: localDateFromKey(travelPlanStartDate),
        endDate: localDateFromKey(travelPlanEndDate, true),
        notes: travelPlanNotes.trim() || undefined,
      });
      setTravelPlanName("");
      setTravelPlanBudget("");
      setTravelPlanStartDate("");
      setTravelPlanEndDate("");
      setTravelPlanNotes("");
      setTravelPlanModal(false);
      setError("");
      await refresh();
    } catch (planError) {
      setError(planError instanceof Error ? planError.message : "出遊規劃建立失敗。");
    } finally {
      setBusy(false);
    }
  };
  const removeTravelPlan = (planId: number) => {
    if (!activeLedger) return;
    setConfirmRequest({
      title: "刪除出遊規劃",
      message: "刪除後不會影響帳本交易，但規劃資料無法復原。",
      confirmText: "確定刪除",
      destructive: true,
      onConfirm: async () => {
        try {
          await api.ledger.deleteTravelPlan.mutate({ ledgerId: activeLedger.id, planId });
          await refresh();
        } catch (planError) {
          setError(planError instanceof Error ? planError.message : "出遊規劃刪除失敗。");
        }
      },
    });
  };
  const updateNickname = async (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) {
      setError("暱稱不能是空白。");
      return;
    }
    setBusy(true);
    try {
      const updated = await api.profile.updateName.mutate({ name: trimmed });
      setUser(current => (current ? { ...current, name: updated.name } : current));
    } catch (nameError) {
      setError(nameError instanceof Error ? nameError.message : "暱稱更新失敗。");
    } finally {
      setBusy(false);
    }
  };
  const confirmDeleteLedger = () => {
    if (!activeLedger) return;
    setConfirmRequest({
      title: "再次確認刪除帳本",
      message: `刪除「${activeLedger.name}」後，帳本資料將無法復原。`,
      confirmText: "確定刪除",
      destructive: true,
      onConfirm: async () => {
        try {
          const ledgerId = activeLedger.id;
          clearLedgerWorkspace();
          setLedgerHome(true);
          setHomePage("ledgers");
          await api.ledger.leave.mutate({ ledgerId, action: "delete" });
          await syncLedgerList(ledgerId);
          leaveLedger();
        } catch (deleteError) {
          setError(deleteError instanceof Error ? deleteError.message : "移除帳本失敗。");
        }
      },
    });
  };
  const performLeaveLedger = async (action: "leave" | "transfer", transferToUserId?: number) => {
    if (!activeLedger) return;
    const ledgerId = activeLedger.id;
    setBusy(true);
    try {
      clearLedgerWorkspace();
      setLedgerHome(true);
      setHomePage("ledgers");
      await api.ledger.leave.mutate({ ledgerId, action, transferToUserId });
      await syncLedgerList(ledgerId);
      leaveLedger();
    } catch (leaveError) {
      setError(leaveError instanceof Error ? leaveError.message : "退出帳本失敗。");
    } finally {
      setBusy(false);
    }
  };
  const requestLeaveLedger = () => {
    if (!activeLedger) return;
    const me = members.find(item => item.user.id === user?.id);
    const others = members.filter(item => item.user.id !== user?.id);
    if (me?.member.role === "admin") {
      setConfirmRequest({
        title: "管理帳本離開方式",
        message: others.length > 0
          ? "你是此帳本的持有者。請選擇新的持有者，或刪除整本帳本。"
          : "你是唯一成員，無法轉讓所有權；若要離開，只能刪除整本帳本。",
        options: [
          ...others.map(item => ({
            label: `轉讓給 ${item.user.name || item.user.email || `成員 ${item.user.id}`}`,
            icon: "account-switch-outline",
            onPress: () => void performLeaveLedger("transfer", item.user.id),
          })),
          { label: "刪除帳本", icon: "delete-outline", destructive: true, onPress: confirmDeleteLedger },
        ],
      });
      return;
    }
    setConfirmRequest({
      title: "退出帳本",
      message: `退出「${activeLedger.name}」後，需要重新取得邀請碼才能加入。`,
      confirmText: "確定退出",
      destructive: true,
      onConfirm: () => performLeaveLedger("leave"),
    });
  };

  const refresh = async () => {
    if (activeLedger) {
      const requestId = ++ledgerRequestRef.current;
      setBusy(true);
      try {
        const applied = await reloadLedger(activeLedger.id, requestId);
        if (applied) await syncLedgerList();
      } catch (refreshError) {
        if (isLedgerAccessError(refreshError)) {
          const removedLedgerId = activeLedger.id;
          clearLedgerWorkspace();
          setLedgerHome(true);
          setHomePage("ledgers");
          await syncLedgerList(removedLedgerId);
          setError("此帳本的存取權限已變更，已從清單移除。");
          return;
        }
        setError(
          refreshError instanceof Error
            ? refreshError.message
            : "資料更新失敗。"
        );
      } finally {
        setBusy(false);
      }
    }
  };
  const handleLogin = async (mode: "signIn" | "signUp" = "signIn") => {
    setError("");
    setBusy(true);
    try {
      await loginWithManus(mode);
      await loadWorkspace();
    } catch (loginError) {
      setError(
        loginError instanceof Error
          ? loginError.message
          : "登入失敗，請稍後再試。"
      );
    } finally {
      setBusy(false);
      setReady(true);
    }
  };
  const finishLedgerAction = async () => {
    setError("");
    if (!ledgerModal) return;
    if (ledgerModal === "create" && !ledgerName.trim()) {
      setError("請輸入帳本名稱。");
      return;
    }
    if (ledgerModal === "join" && inviteCode.trim().length < 4) {
      setError("請輸入有效的邀請碼。");
      return;
    }
    setBusy(true);
    try {
      if (ledgerModal === "create")
        await api.ledger.create.mutate({
          name: ledgerName.trim(),
          type: ledgerType,
        });
      else {
        const joined = await api.ledger.join.mutate({
          inviteCode: inviteCode.trim().toUpperCase(),
        });
        if (!joined) throw new Error("找不到這組邀請碼，請確認後再試。");
      }
      setLedgerModal(null);
      setLedgerName("");
      setInviteCode("");
      setLedgerType("couple");
      await loadWorkspace();
    } catch (actionError) {
      setError(
        actionError instanceof Error ? actionError.message : "帳本操作失敗。"
      );
    } finally {
      setBusy(false);
    }
  };
  const performLogout = async () => {
    setBusy(true);
    try {
      await api.auth.logout.mutate();
    } catch {
      /* native token removal remains authoritative */
    }
    await clearSessionToken();
    setUser(null);
    setLedgers([]);
    clearLedgerWorkspace();
    setLedgerHome(true);
    setError("");
    setBusy(false);
  };
  const logout = () => {
    setConfirmRequest({
      title: "確認登出",
      message: "登出後需要重新登入才能查看共同帳本。",
      confirmText: "登出",
      destructive: true,
      onConfirm: performLogout,
    });
  };
  const openNewTransaction = () => {
    setEditingTransaction(null);
    setTransactionModal(true);
  };
  const openEditTransaction = (transaction: Transaction) => {
    setConfirmRequest({
      title: "編輯收支",
      message: "將開啟編輯表單；尚未儲存前不會修改帳本資料。",
      confirmText: "開啟編輯",
      onConfirm: () => {
        setEditingTransaction(transaction);
        setTransactionModal(true);
      },
    });
  };
  const removeTransaction = (transaction: Transaction) => {
    setConfirmRequest({
      title: "確認移除收支",
      message: "這筆收支會從目前帳本移除。下一步會再確認一次。",
      confirmText: "下一步",
      onConfirm: () => {
        setConfirmRequest({
          title: "再次確認移除",
          message: "移除後只能從操作日誌查看事件，無法自動復原。",
          confirmText: "確定移除",
          destructive: true,
          onConfirm: async () => {
            try {
              await api.ledger.deleteTransaction.mutate({
                ledgerId: activeLedger!.id,
                transactionId: transaction.id,
              });
              await refresh();
            } catch (removeError) {
              setError(removeError instanceof Error ? removeError.message : "移除收支失敗。");
            }
          },
        });
      },
    });
  };
  const archiveCategoryItem = async (categoryId: number) => {
    try {
      await api.ledger.archiveCategory.mutate({ ledgerId: activeLedger!.id, categoryId });
      await refresh();
    } catch (archiveError) {
      setError(archiveError instanceof Error ? archiveError.message : "移除分類失敗。");
    }
  };
  const archivePaymentItem = async (paymentMethodId: number) => {
    try {
      await api.ledger.archivePaymentMethod.mutate({ ledgerId: activeLedger!.id, paymentMethodId });
      await refresh();
    } catch (archiveError) {
      setError(archiveError instanceof Error ? archiveError.message : "移除支付方式失敗。");
    }
  };
  const afterMutation = async () => {
    setTransactionModal(false);
    setEditingTransaction(null);
    setBudgetModal(false);
    setRecurringModal(false);
    setSettingsModal(null);
    await refresh();
  };

  if (!ready)
    return (
      <View style={styles.loadingScreen}>
        <ActivityIndicator color={colors.rose} />
        <Text style={styles.loadingText}>正在準備共帳…</Text>
      </View>
    );
  if (!user)
    return <LoginScreen error={error} busy={busy} onLogin={handleLogin} />;
    const homeHeaderAction = (
    <View style={styles.headerActions}>
      <Pressable
        onPress={() => setHomePage(current => current === "profile" ? "ledgers" : "profile")}
        style={styles.headerBackButton}
        accessibilityLabel="個人設定"
        accessibilityRole="button"
      >
        <MaterialCommunityIcons name={homePage === "profile" ? "arrow-left" : "account-outline"} size={19} color={palette.rose} />
      </Pressable>
    </View>
  );

  if (ledgers.length === 0)
    return (
      <>
        <AppHeader
          title={homePage === "profile" ? "個人設定" : "共帳"}
          caption={homePage === "profile" ? "管理你的 App 偏好" : "建立你的共同財務空間"}
          action={homeHeaderAction}
        />
        {homePage === "profile" ? (
          <PersonalSettingsPage user={user} error={error} onUpdateNickname={updateNickname} onLogout={logout} onBack={() => setHomePage("ledgers")} />
        ) : (
          <EmptyLedger
            error={error}
            onCreate={() => {
              setError("");
              setLedgerModal("create");
            }}
            onJoin={() => {
              setError("");
              setLedgerModal("join");
            }}
          />
        )}
        <LedgerModal
          mode={ledgerModal}
          ledgerName={ledgerName}
          inviteCode={inviteCode}
          ledgerType={ledgerType}
          error={error}
          busy={busy}
          setLedgerName={setLedgerName}
          setInviteCode={setInviteCode}
          setLedgerType={setLedgerType}
          onClose={() => {
            setError("");
            setLedgerModal(null);
          }}
          onSubmit={finishLedgerAction}
        />
        <ConfirmModal request={confirmRequest} onClose={() => setConfirmRequest(null)} />
      </>
    );

  if (ledgerHome)
    return (
      <SafeAreaView style={[styles.screen, { backgroundColor: palette.background }]} edges={["top", "bottom"]}>
        <AppHeader
          title={homePage === "profile" ? "個人設定" : "我的帳本"}
          caption={homePage === "profile" ? "管理你的 App 偏好" : "選擇要進入的共同空間"}
          action={homeHeaderAction}
        />
        {homePage === "profile" ? (
          <PersonalSettingsPage user={user} error={error} onUpdateNickname={updateNickname} onLogout={logout} onBack={() => setHomePage("ledgers")} />
        ) : (
          <LedgerHome
            ledgers={ledgers}
            onSelect={selectLedger}
            onCreate={() => {
              setError("");
              setLedgerModal("create");
            }}
            onJoin={() => {
              setError("");
              setLedgerModal("join");
            }}
          />
        )}
        <LedgerModal
          mode={ledgerModal}
          ledgerName={ledgerName}
          inviteCode={inviteCode}
          ledgerType={ledgerType}
          error={error}
          busy={busy}
          setLedgerName={setLedgerName}
          setInviteCode={setInviteCode}
          setLedgerType={setLedgerType}
          onClose={() => {
            setError("");
            setLedgerModal(null);
          }}
          onSubmit={finishLedgerAction}
        />
        <ConfirmModal request={confirmRequest} onClose={() => setConfirmRequest(null)} />
      </SafeAreaView>
    );

  const content =
    activeAction === "overview" ? (
      <Overview
        ledger={activeLedger!}
        user={user}
        members={members}
        analytics={analytics}
        settlement={settlement}
        transactions={transactions}
        categories={categories}
        onAdd={openNewTransaction}
        onEdit={openEditTransaction}
        onDelete={removeTransaction}
        onSettle={async () => {
          if (!activeLedger) return;
          setBusy(true);
          try {
            await api.ledger.settlement.markSettled.mutate({
              ledgerId: activeLedger.id,
              month: currentMonth(),
            });
            await refresh();
          } catch (settleError) {
            setError(
              settleError instanceof Error ? settleError.message : "結算失敗。"
            );
          } finally {
            setBusy(false);
          }
        }}
      />
    ) : activeAction === "calendar" ? (
      <CalendarSection
        transactions={calendarTransactions}
        categories={categories}
        onEdit={openEditTransaction}
        onDelete={removeTransaction}
      />
    ) : activeAction === "analysis" ? (
      <AnalysisSection
        analytics={analytics}
        previousAnalytics={previousAnalytics}
      />
    ) : activeAction === "planning" ? (
      <PlanningSection
        analytics={analytics}
        budgets={budgets}
        travelPlans={travelPlans}
        categories={categories}
        recurring={recurring}
        onBudget={() => setBudgetModal(true)}
        onTravelPlan={() => setTravelPlanModal(true)}
        onDeleteTravelPlan={removeTravelPlan}
        onRecurring={() => setRecurringModal(true)}
      />
    ) : (
      <SettingsSection
        ledger={activeLedger!}
        user={user}
        members={members}
        categories={categories}
        paymentMethods={paymentMethods}
        history={settlementHistory}
        activityLogs={activityLogs}
        onRenameLedger={() => setLedgerManageModal("rename")}
        onTransferOwnership={() => setLedgerManageModal("transfer")}
        onCategory={() => setSettingsModal("category")}
        onPayment={() => setSettingsModal("payment")}
        onArchiveCategory={archiveCategoryItem}
        onArchivePayment={archivePaymentItem}
        onRefresh={refresh}
        onLeaveLedger={requestLeaveLedger}
        onRoleChange={async (memberId, role) => {
          try {
            await api.ledger.updateMemberRole.mutate({
              ledgerId: activeLedger!.id,
              userId: memberId,
              role,
            });
            await refresh();
          } catch (roleError) {
            setError(
              roleError instanceof Error ? roleError.message : "權限更新失敗。"
            );
          }
        }}
      />
    );

  return (
    <SafeAreaView
      style={[styles.screen, { backgroundColor: palette.background }]}
      edges={["top", "bottom"]}
    >
      <AppHeader
        title={actionLabel(activeAction)}
        caption={activeLedger?.name || "共同帳本"}
        action={
          <View style={styles.headerActions}>
            <Pressable
              accessibilityLabel="返回我的帳本"
              accessibilityRole="button"
              onPress={leaveLedger}
              style={styles.headerBackButton}
            >
              <MaterialCommunityIcons name="arrow-left" size={19} color={colors.muted} />
            </Pressable>
            <Pressable onPress={refresh} style={styles.headerAddButton} accessibilityLabel="重新整理">
              <MaterialCommunityIcons
                name={busy ? "sync" : "refresh"}
                size={19}
                color="#FFFFFF"
              />
            </Pressable>
          </View>
        }
      />
      <ScrollView
        style={{ backgroundColor: palette.background }}
        contentContainerStyle={styles.pageContent}
      >
        <LedgerSelector
          ledgers={ledgers}
          activeLedgerId={activeLedger!.id}
          onSelect={selectLedger}
        />
        {!!error && <Text style={styles.globalError}>{error}</Text>}
        {content}
      </ScrollView>
      <QuickNav active={activeAction} onSelect={setActiveAction} />
      <TransactionModal
        visible={transactionModal}
        editingTransaction={editingTransaction}
        user={user}
        members={members}
        categories={categories}
        paymentMethods={paymentMethods}
        error={error}
        onClose={() => {
          setTransactionModal(false);
          setEditingTransaction(null);
        }}
        onSetupPayment={() => {
          setTransactionModal(false);
          setActiveAction("settings");
          setSettingsModal("payment");
        }}
        onSubmit={async input => {
          try {
            if (editingTransaction) {
              await api.ledger.updateTransaction.mutate({
                ledgerId: activeLedger!.id,
                transactionId: editingTransaction.id,
                ...input,
              });
            } else {
              await api.ledger.createTransaction.mutate({
                ledgerId: activeLedger!.id,
                ...input,
              });
            }
            await afterMutation();
          } catch (mutationError) {
            setError(
              mutationError instanceof Error
                ? mutationError.message
                : "新增交易失敗。"
            );
          }
        }}
      />
      <BudgetModal
        visible={budgetModal}
        categories={categories}
        currentMonth={currentMonth()}
        ledgerId={activeLedger!.id}
        onClose={() => setBudgetModal(false)}
        onSubmit={async input => {
          try {
            await api.ledger.upsertBudget.mutate(input);
            await afterMutation();
          } catch (mutationError) {
            setError(
              mutationError instanceof Error
                ? mutationError.message
                : "預算儲存失敗。"
            );
          }
        }}
      />
      <RecurringModal
        visible={recurringModal}
        categories={categories}
        paymentMethods={paymentMethods}
        ledgerId={activeLedger!.id}
        onClose={() => setRecurringModal(false)}
        onSubmit={async input => {
          try {
            await api.ledger.createRecurring.mutate({
              ledgerId: activeLedger!.id,
              ...input,
            });
            await afterMutation();
          } catch (mutationError) {
            setError(
              mutationError instanceof Error
                ? mutationError.message
                : "固定收支儲存失敗。"
            );
          }
        }}
      />
      <LedgerManageModal
        visible={ledgerManageModal !== null}
        mode={ledgerManageModal || "rename"}
        ledger={activeLedger!}
        members={members}
        user={user}
        error={error}
        busy={busy}
        onClose={() => {
          setLedgerManageModal(null);
          setError("");
        }}
        onRename={updateLedgerName}
        onTransfer={transferOwnership}
      />
      <TravelPlanModal
        visible={travelPlanModal}
        name={travelPlanName}
        budget={travelPlanBudget}
        startDate={travelPlanStartDate}
        endDate={travelPlanEndDate}
        notes={travelPlanNotes}
        error={error}
        busy={busy}
        setName={setTravelPlanName}
        setBudget={setTravelPlanBudget}
        setStartDate={setTravelPlanStartDate}
        setEndDate={setTravelPlanEndDate}
        setNotes={setTravelPlanNotes}
        onClose={() => {
          setTravelPlanModal(false);
          setError("");
        }}
        onSubmit={createTravelPlan}
      />
      <SettingsModal
        visible={settingsModal !== null}
        mode={settingsModal || "category"}
        ledgerId={activeLedger!.id}
        categories={categories}
        onClose={() => setSettingsModal(null)}
        onSubmit={async input => {
          try {
            if (settingsModal === "category")
              await api.ledger.createCategory.mutate({
                ledgerId: activeLedger!.id,
                parentCategoryId: input.parentCategoryId,
                name: input.name,
                type: input.type,
                icon: input.icon,
                color: colors.rose,
              });
            else
              await api.ledger.createPaymentMethod.mutate({
                ledgerId: activeLedger!.id,
                name: input.name,
                icon: input.icon,
              });
            await afterMutation();
          } catch (mutationError) {
            setError(
              mutationError instanceof Error
                ? mutationError.message
                : "設定儲存失敗。"
            );
          }
                }}
      />
      <ConfirmModal request={confirmRequest} onClose={() => setConfirmRequest(null)} />
    </SafeAreaView>
  );
}
function LoginScreen({

  error,
  busy,
  onLogin,
}: {
  error: string;
  busy: boolean;
  onLogin: (mode: "signIn" | "signUp") => void;
}) {
  const { palette } = useAppearance();
  return (
    <SafeAreaView style={[styles.screen, { backgroundColor: palette.background }]} edges={["top", "bottom"]}>
      <ScrollView contentContainerStyle={styles.loginContent}>
        <View style={styles.brandMark}>
          <MaterialCommunityIcons name="heart" size={28} color={colors.rose} />
        </View>
        <Text style={styles.brandTitle}>共帳</Text>
        <Text style={styles.brandSubtitle}>TOGETHER LEDGER</Text>
        <Text style={styles.loginHeading}>
          和重要的人，{"\n"}一起把生活記清楚。
        </Text>
        <Text style={styles.loginDescription}>
          專為情侶、室友與家庭設計的共同帳本。
        </Text>
        <View style={styles.formCard}>
          <Text style={styles.formTitle}>登入／註冊共帳</Text>
          <Text style={styles.formBody}>
            請點擊下方按鈕登入或註冊您的共帳帳號。登入後可建立新帳本或透過邀請加入共同記帳空間。
          </Text>
          {!!error && <Text style={styles.errorText}>{error}</Text>}
          <Pressable
            disabled={busy}
            onPress={() => onLogin("signIn")}
            style={({ pressed }) => [
              styles.primaryButton,
              pressed && styles.pressed,
              busy && styles.disabled,
            ]}
          >
            <Text style={styles.primaryButtonText}>
              {busy ? "處理中…" : "登入"}
            </Text>
            {busy ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <MaterialCommunityIcons
                name="arrow-right"
                size={19}
                color="#FFFFFF"
              />
            )}
          </Pressable>
          <Pressable
            disabled={busy}
            onPress={() => onLogin("signUp")}
            style={({ pressed }) => [
              styles.secondaryButton,
              pressed && styles.pressed,
              busy && styles.disabled,
            ]}
          >
            <Text style={styles.secondaryButtonText}>第一次使用？建立帳號</Text>
          </Pressable>
        </View>
        <Text style={styles.privacyText}>
          新帳本完全空白，所有交易與預算均由雙方手動記錄。
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function AppHeader({
  title,
  caption,
  action,
}: {
  title: string;
  caption: string;
  action?: ReactNode;
}) {
  const { palette } = useAppearance();
  return (
    <SafeAreaView edges={["top"]} style={[styles.headerSafe, { backgroundColor: palette.surface }]}>
      <View style={[styles.appHeader, { borderBottomColor: palette.border }]}>
        <View style={styles.smallMark}>
          <MaterialCommunityIcons name="heart-multiple-outline" size={22} color={colors.rose} />
        </View>
        <View style={styles.headerTitleWrap}>
          <Text style={styles.headerTitle}>{title}</Text>
          <Text style={styles.headerCaption}>{caption}</Text>
        </View>
        {action || <View style={styles.headerSpacer} />}
      </View>
    </SafeAreaView>
  );
}

function LedgerSelector({
  ledgers,
  activeLedgerId,
  onSelect,
}: {
  ledgers: Ledger[];
  activeLedgerId: number;
  onSelect: (ledger: Ledger) => void;
}) {
  const { palette } = useAppearance();
  return (
    <View style={styles.ledgerSelector}>
      <Text style={styles.selectorLabel}>目前帳本</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {ledgers.map(ledger => (
          <Pressable
            key={ledger.id}
            onPress={() => onSelect(ledger)}
            style={[
              styles.ledgerChip,
              ledger.id === activeLedgerId && styles.ledgerChipActive,
            ]}
          >
            <MaterialCommunityIcons
              name={ledger.type === "couple" ? "heart-outline" : "account-group-outline"}
              size={15}
              color={ledger.id === activeLedgerId ? palette.rose : palette.muted}
            />
            <Text
              numberOfLines={1}
              style={[
                styles.ledgerChipText,
                ledger.id === activeLedgerId && styles.ledgerChipTextActive,
              ]}
            >
              {ledger.name}
            </Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

function LedgerHome({
  ledgers,
  onSelect,
  onCreate,
  onJoin,
}: {
  ledgers: Ledger[];
  onSelect: (ledger: Ledger) => void;
  onCreate: () => void;
  onJoin: () => void;
}) {
  const { palette } = useAppearance();
  const [ledgerQuery, setLedgerQuery] = useState("");
  const visibleLedgers = useMemo(() => {
    const query = ledgerQuery.trim().toLocaleLowerCase();
    if (!query) return ledgers;
    return ledgers.filter(ledger => ledger.name.toLocaleLowerCase().includes(query));
  }, [ledgerQuery, ledgers]);
  return (
    <ScrollView contentContainerStyle={styles.ledgerHomeContent}>
      <SectionIntro
        eyebrow="MY LEDGERS"
        title="選擇共同帳本"
        body="先選擇要進入的空間，也可以建立新的帳本或使用邀請碼加入。"
      />
      <TextInput
        value={ledgerQuery}
        onChangeText={setLedgerQuery}
        placeholder="搜尋帳本名稱"
        placeholderTextColor={palette.muted}
        style={styles.input}
        accessibilityLabel="搜尋帳本名稱"
      />
      <View style={styles.settingsFilterRow}>
        <Text style={styles.rowSubtitle}>{visibleLedgers.length} 個帳本</Text>
        {!!ledgerQuery.trim() && <Pressable onPress={() => setLedgerQuery("")}><Text style={styles.settingsFilterText}>清除搜尋</Text></Pressable>}
      </View>
      {visibleLedgers.length === 0 ? <EmptyInline text="找不到符合的帳本名稱。" /> : visibleLedgers.map(ledger => (
        <Pressable
          key={ledger.id}
          onPress={() => onSelect(ledger)}
          style={({ pressed }) => [styles.ledgerHomeCard, pressed && styles.pressed]}
        >
          <View style={styles.ledgerHomeIcon}>
            <MaterialCommunityIcons
              name={ledger.type === "couple" ? "heart-outline" : "account-group-outline"}
              size={23}
              color={palette.rose}
            />
          </View>
          <View style={styles.memberPaymentName}>
            <Text style={styles.cardTitle}>{ledger.name}</Text>
            <Text style={styles.rowSubtitle}>點擊進入共同帳本</Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={22} color={palette.muted} />
        </Pressable>
      ))}
      <View style={styles.actionRow}>
        <Pressable onPress={onCreate} style={styles.actionButton}>
          <MaterialCommunityIcons name="plus" size={19} color="#FFFFFF" />
          <Text style={styles.actionButtonText}>建立帳本</Text>
        </Pressable>
        <Pressable onPress={onJoin} style={styles.secondaryActionButton}>
          <MaterialCommunityIcons name="account-multiple-plus-outline" size={19} color={palette.rose} />
          <Text style={styles.secondaryActionButtonText}>加入帳本</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

function EmptyLedger({
  error,
  onCreate,
  onJoin,
}: {
  error: string;
  onCreate: () => void;
  onJoin: () => void;
}) {
  const { palette } = useAppearance();
  return (
    <SafeAreaView style={[styles.screen, { backgroundColor: palette.background }]} edges={["bottom"]}>
      <ScrollView contentContainerStyle={styles.emptyContent}>
        <View style={styles.emptyIllustration}>
          <MaterialCommunityIcons
            name="book-heart-outline"
            size={52}
            color={colors.rose}
          />
        </View>
        <Text style={styles.emptyTitle}>目前還沒有帳本</Text>
        <Text style={styles.emptyDescription}>
          這裡保持空白，不會替你建立範例交易或預算。建立新的共同帳本，或輸入邀請碼加入成員的帳本。
        </Text>
        {!!error && <Text style={styles.errorText}>{error}</Text>}
        <Pressable
          onPress={onCreate}
          style={({ pressed }) => [
            styles.primaryButton,
            pressed && styles.pressed,
          ]}
        >
          <MaterialCommunityIcons name="plus" size={20} color="#FFFFFF" />
          <Text style={styles.primaryButtonText}>建立第一個帳本</Text>
        </Pressable>
        <Pressable
          onPress={onJoin}
          style={({ pressed }) => [
            styles.secondaryButton,
            pressed && styles.pressed,
          ]}
        >
          <MaterialCommunityIcons
            name="account-multiple-plus-outline"
            size={20}
            color={colors.rose}
          />
          <Text style={styles.secondaryButtonText}>使用邀請碼加入</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

function Overview({
  ledger,
  user,
  members,
  analytics,
  settlement,
  transactions,
  categories,
  onAdd,
  onEdit,
  onDelete,
  onSettle,
}: {
  ledger: Ledger;
  user: User;
  members: LedgerMember[];
  analytics: Analytics | null;
  settlement: Settlement | null;
  transactions: Transaction[];
  categories: Category[];
  onAdd: () => void;
  onEdit: (transaction: Transaction) => void;
  onDelete: (transaction: Transaction) => void;
  onSettle: () => void;
}) {
  const { palette } = useAppearance();
  const memberNames = members
    .map(item => item.user.name || item.user.email || "成員")
    .join(" ＆ ");
  const paymentByMember = members.map(member => ({
    ...member,
    total: transactions
      .filter(tx => tx.payerId === member.user.id && tx.type === "expense")
      .reduce((sum, tx) => sum + tx.amount, 0),
  }));
  const topCategory = analytics?.categories[0];
  const pending = settlement?.settlement;
  return (
    <>
      <View style={styles.heroCard}>
        <Text style={styles.heroEyebrow}>
          {ledger.type === "couple" ? "情侶共同帳本" : "多人共同帳本"}
        </Text>
        <Text style={styles.heroTitle}>{ledger.name}</Text>
        <Text style={styles.heroBody}>
          把每一份共同支出清楚記下來，讓生活更透明。
        </Text>
        <View style={styles.heroFooter}>
          <MaterialCommunityIcons
            name="account-multiple-outline"
            size={17}
            color="#F8E9E5"
          />
          <Text style={styles.heroFooterText}>
            {members.length} 位成員 · {memberNames || "等待成員加入"}
          </Text>
        </View>
      </View>
      <View style={styles.actionRow}>
        <Pressable
          onPress={onAdd}
          style={({ pressed }) => [
            styles.actionButton,
            pressed && styles.pressed,
          ]}
        >
          <MaterialCommunityIcons name="cash-plus" size={20} color="#FFFFFF" />
          <Text style={styles.actionButtonText}>新增收支</Text>
        </Pressable>
        <View style={styles.inviteBadge}>
          <Text style={styles.inviteBadgeLabel}>邀請碼</Text>
          <Text style={styles.inviteBadgeValue}>{ledger.inviteCode}</Text>
        </View>
      </View>
      <View style={styles.statRow}>
        <StatCard
          label="本月收入"
          value={money(analytics?.income || 0)}
          icon="cash-plus"
        />
        <StatCard
          label="本月支出"
          value={money(analytics?.expense || 0)}
          icon="cash-minus"
        />
      </View>
      <View style={styles.balanceCard}>
        <View>
          <Text style={styles.balanceLabel}>本月結餘</Text>
          <Text style={styles.balanceValue}>
            {money(analytics?.balance || 0)}
          </Text>
        </View>
        <MaterialCommunityIcons
          name="chart-donut"
          size={36}
          color={palette.rose}
        />
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <Text style={styles.cardTitle}>雙方支付總覽</Text>
          <Text style={styles.cardHint}>本月</Text>
        </View>
        <ScrollView style={styles.paymentOverviewScroll} nestedScrollEnabled>
          {paymentByMember.map(member => (
          <View key={member.user.id} style={styles.memberPaymentRow}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>
                {(member.user.name || member.user.email || "成").slice(0, 1)}
              </Text>
            </View>
            <View style={styles.memberPaymentName}>
              <Text style={styles.rowTitle}>
                {member.user.id === user.id
                  ? "你"
                  : member.user.name || member.user.email || "成員"}
              </Text>
              <Text style={styles.rowSubtitle}>
                {member.member.role === "admin"
                  ? "管理員"
                  : member.member.role === "viewer"
                    ? "檢視者"
                    : "成員"}
              </Text>
            </View>
            <Text style={styles.rowAmount}>{money(member.total)}</Text>
          </View>
          ))}
        </ScrollView>
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <Text style={styles.cardTitle}>最近收支</Text>
          <Text style={styles.cardHint}>{Math.min(transactions.length, 8)} 筆</Text>
        </View>
        {transactions.length === 0 ? (
          <EmptyInline text="目前沒有收支記錄。" />
        ) : (
          <ScrollView
            style={styles.recentTransactionsScroll}
            nestedScrollEnabled
            showsVerticalScrollIndicator
          >
            {transactions.slice(0, 8).map(tx => (
              <TransactionRow
                key={tx.id}
                transaction={tx}
                categories={categories}
                onEdit={onEdit}
                onDelete={onDelete}
              />
            ))}
          </ScrollView>
        )}
      </View>
      <View style={styles.insightCard}>
        <MaterialCommunityIcons
          name="star-outline"
          size={21}
          color={palette.rose}
        />
        <View style={styles.insightText}>
          <Text style={styles.insightTitle}>共同財務摘要</Text>
          <Text style={styles.insightBody}>
            {topCategory
              ? `本月最高支出分類是「${topCategory.name}」，共 ${money(topCategory.amount)}。`
              : "目前還沒有收支記錄，新增第一筆交易後會在這裡看到分析。"}
          </Text>
        </View>
      </View>
      <View style={styles.settlementCard}>
        <View style={styles.settlementIcon}>
          <MaterialCommunityIcons
            name="hand-coin-outline"
            size={22}
            color={palette.rose}
          />
        </View>
        <View style={styles.settlementText}>
          <Text style={styles.settlementTitle}>目前結算狀態</Text>
          <Text style={styles.settlementBody}>
            {pending
              ? `由 ${members.find(member => member.user.id === pending.fromUserId)?.user.name || "成員"} 支付 ${money(pending.amount)} 給 ${members.find(member => member.user.id === pending.toUserId)?.user.name || "成員"}`
              : "目前沒有待結算差額。"}
          </Text>
        </View>
        {pending && (
          <Pressable onPress={onSettle} style={styles.smallButton}>
            <Text style={styles.smallButtonText}>已結算</Text>
          </Pressable>
        )}
      </View>
    </>
  );
}

function StatCard({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon: keyof typeof MaterialCommunityIcons.glyphMap;
}) {
  const { palette } = useAppearance();
  return (
    <View style={styles.statCard}>
      <View style={styles.statIcon}>
        <MaterialCommunityIcons name={icon} size={17} color={palette.rose} />
      </View>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  );
}

function CalendarSection({
  transactions,
  categories,
  onEdit,
  onDelete,
}: {
  transactions: Transaction[];
  categories: Category[];
  onEdit: (transaction: Transaction) => void;
  onDelete: (transaction: Transaction) => void;
}) {
  const { palette } = useAppearance();
  const month = currentMonth();
  const [selected, setSelected] = useState(dateKey(new Date()));
  const [year, monthNumber] = month.split("-").map(Number);
  const firstDay = new Date(year, monthNumber - 1, 1).getDay();
  const days = new Date(year, monthNumber, 0).getDate();
  const cells = Array.from({ length: firstDay + days }, (_, index) =>
    index < firstDay ? null : index - firstDay + 1
  );
  const selectedTransactions = transactions.filter(
    tx => dateKey(tx.date) === selected
  );
  const totalByDay = new Map<number, number>();
  transactions.forEach(tx => {
    const d = new Date(tx.date);
    if (d.getMonth() === monthNumber - 1 && d.getFullYear() === year)
      totalByDay.set(
        d.getDate(),
        (totalByDay.get(d.getDate()) || 0) +
          (tx.type === "expense" ? tx.amount : -tx.amount)
      );
  });
  return (
    <>
      <SectionIntro
        eyebrow="MONTHLY VIEW"
        title={`${year} 年 ${monthNumber} 月`}
        body="點選日期查看當天的收支明細。"
      />
      <View style={styles.card}>
        <View style={styles.weekRow}>
          {["日", "一", "二", "三", "四", "五", "六"].map(day => (
            <Text key={day} style={styles.weekLabel}>
              {day}
            </Text>
          ))}
        </View>
        <View style={styles.calendarGrid}>
          {cells.map((day, index) =>
            day === null ? (
              <View key={`empty-${index}`} style={styles.calendarCell} />
            ) : (
              <Pressable
                key={day}
                onPress={() =>
                  setSelected(
                    `${year}-${String(monthNumber).padStart(2, "0")}-${String(day).padStart(2, "0")}`
                  )
                }
                style={[
                  styles.calendarCell,
                  selected.endsWith(`-${String(day).padStart(2, "0")}`) &&
                    styles.calendarSelected,
                ]}
              >
                <Text
                  style={[
                    styles.calendarDay,
                    selected.endsWith(`-${String(day).padStart(2, "0")}`) &&
                      styles.calendarDaySelected,
                  ]}
                >
                  {day}
                </Text>
                {totalByDay.has(day) && (
                  <View
                    style={[
                      styles.calendarDot,
                      {
                        backgroundColor:
                          (totalByDay.get(day) || 0) > 0
                            ? palette.orange
                            : palette.sage,
                      },
                    ]}
                  />
                )}
              </Pressable>
            )
          )}
        </View>
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <Text style={styles.cardTitle}>
            {selected.slice(5).replace("-", " / ")} 明細
          </Text>
          <Text style={styles.cardHint}>{selectedTransactions.length} 筆</Text>
        </View>
        {selectedTransactions.length === 0 ? (
          <EmptyInline text="這天還沒有收支記錄。" />
        ) : (
          selectedTransactions.map(tx => (
            <TransactionRow
              key={tx.id}
              transaction={tx}
              categories={categories}
              onEdit={onEdit}
              onDelete={onDelete}
            />
          ))
        )}
      </View>
    </>
  );
}

function ExpenseDonut({
  categories,
}: {
  categories: Analytics["categories"];
}) {
  const { palette } = useAppearance();
  const size = 172;
  const strokeWidth = 23;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const total = categories.reduce((sum, item) => sum + item.amount, 0);
  let offset = 0;
  return (
    <View style={styles.donutWrap}>
      <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={palette.border}
          strokeWidth={strokeWidth}
          fill="none"
        />
        {categories.map(category => {
          const length = total > 0 ? (category.amount / total) * circumference : 0;
          const dashOffset = -offset;
          offset += length;
          return (
            <Circle
              key={category.id}
              cx={size / 2}
              cy={size / 2}
              r={radius}
              stroke={category.color || palette.rose}
              strokeWidth={strokeWidth}
              strokeLinecap="butt"
              fill="none"
              strokeDasharray={`${length} ${circumference - length}`}
              strokeDashoffset={dashOffset}
              rotation="-90"
              origin={`${size / 2}, ${size / 2}`}
            />
          );
        })}
      </Svg>
      <View style={styles.donutCenter}>
        <Text style={styles.donutCenterLabel}>總支出</Text>
        <Text style={styles.donutCenterValue}>{money(total)}</Text>
      </View>
    </View>
  );
}

function AnalysisSection({
  analytics,
  previousAnalytics,
}: {
  analytics: Analytics | null;
  previousAnalytics: Analytics | null;
}) {
  const { palette } = useAppearance();
  const expenseChange = previousAnalytics?.expense
    ? Math.round(
        (((analytics?.expense || 0) - previousAnalytics.expense) /
          previousAnalytics.expense) *
          100
      )
    : 0;
  return (
    <>
      <SectionIntro
        eyebrow="FINANCE DASHBOARD"
        title="看見共同生活的流向"
        body="用分類與月份趨勢掌握收入、支出與餘額。"
      />
      <View style={styles.statRow}>
        <StatCard
          label="收入"
          value={money(analytics?.income || 0)}
          icon="cash-plus"
        />
        <StatCard
          label="支出"
          value={money(analytics?.expense || 0)}
          icon="cash-minus"
        />
      </View>
      <View style={styles.balanceCard}>
        <View>
          <Text style={styles.balanceLabel}>目前餘額</Text>
          <Text style={styles.balanceValue}>
            {money(analytics?.balance || 0)}
          </Text>
        </View>
        <Text style={styles.trendText}>
          {expenseChange > 0
            ? `支出較上月 +${expenseChange}%`
            : expenseChange < 0
              ? `支出較上月 ${expenseChange}%`
              : "與上月相比持平"}
        </Text>
      </View>
      {!!analytics?.categories.length && (
        <View style={styles.card}>
          <View style={styles.cardHeading}>
            <Text style={styles.cardTitle}>支出比例</Text>
            <MaterialCommunityIcons name="chart-donut" size={20} color={palette.rose} />
          </View>
          <View style={styles.donutLayout}>
            <ExpenseDonut categories={analytics.categories} />
            <View style={styles.donutLegend}>
              {analytics.categories.slice(0, 5).map(category => (
                <View key={`legend-${category.id}`} style={styles.donutLegendRow}>
                  <View style={[styles.donutLegendDot, { backgroundColor: category.color || palette.rose }]} />
                  <Text style={styles.donutLegendName} numberOfLines={1}>{category.name}</Text>
                  <Text style={styles.donutLegendAmount}>{money(category.amount)}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>
      )}
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <Text style={styles.cardTitle}>支出分類</Text>
          <MaterialCommunityIcons
            name="chart-donut"
            size={20}
            color={palette.rose}
          />
        </View>
        {analytics?.categories.length ? (
          analytics.categories.map(category => {
            const max = analytics.categories[0]?.amount || 1;
            return (
              <View key={category.id} style={styles.barRow}>
                <View style={styles.barLabelRow}>
                  <Text style={styles.rowTitle}>{category.name}</Text>
                  <Text style={styles.rowAmount}>{money(category.amount)}</Text>
                </View>
                <View style={styles.barTrack}>
                  <View
                    style={[
                      styles.barFill,
                      {
                        width: `${Math.max(5, (category.amount / max) * 100)}%`,
                        backgroundColor: category.color,
                      },
                    ]}
                  />
                </View>
              </View>
            );
          })
        ) : (
          <EmptyInline text="新增支出後會顯示分類圖表。" />
        )}
      </View>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>月份趨勢比較</Text>
        <View style={styles.compareRow}>
          <CompareItem
            label="本月支出"
            value={analytics?.expense || 0}
            color={palette.rose}
          />
          <CompareItem
            label="上月支出"
            value={previousAnalytics?.expense || 0}
            color="#D9C2B8"
          />
        </View>
      </View>
    </>
  );
}

function CompareItem({
  label,
  value,
  color,
}: {
  label: string;
  value: number;
  color: string;
}) {
  const { palette } = useAppearance();
  return (
    <View style={styles.compareItem}>
      <View style={[styles.compareSwatch, { backgroundColor: color }]} />
      <Text style={styles.rowSubtitle}>{label}</Text>
      <Text style={styles.rowAmount}>{money(value)}</Text>
    </View>
  );
}

function PlanningSection({
  analytics,
  budgets,
  travelPlans,
  categories,
  recurring,
  onBudget,
  onTravelPlan,
  onDeleteTravelPlan,
  onRecurring,
}: {
  analytics: Analytics | null;
  budgets: Budget[];
  travelPlans: TravelPlan[];
  categories: Category[];
  recurring: Recurring[];
  onBudget: () => void;
  onTravelPlan: () => void;
  onDeleteTravelPlan: (planId: number) => void;
  onRecurring: () => void;
}) {
  const { palette } = useAppearance();
  const totalBudget = budgets.find(item => item.categoryId === 0);
  const spent = analytics?.expense || 0;
  const totalPercent = totalBudget
    ? Math.min(100, Math.round((spent / totalBudget.amount) * 100))
    : 0;
  return (
    <>
      <SectionIntro
        eyebrow="PLAN TOGETHER"
        title="預算與固定收支"
        body="先設定界線，再讓固定的生活支出自動記錄。"
      />
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <View>
            <Text style={styles.cardTitle}>每月總預算</Text>
            <Text style={styles.cardHint}>
              {totalBudget
                ? `${money(spent)} / ${money(totalBudget.amount)}`
                : "尚未設定"}
            </Text>
          </View>
          <Pressable onPress={onBudget} style={styles.outlineIconButton}>
            <MaterialCommunityIcons
              name="pencil-outline"
              size={17}
              color={palette.rose}
            />
          </Pressable>
        </View>
        {totalBudget ? (
          <>
            <View style={styles.progressTrack}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: `${totalPercent}%`,
                    backgroundColor:
                      totalPercent >= 100 ? "#C25C5C" : palette.rose,
                  },
                ]}
              />
            </View>
            <Text
              style={[
                styles.progressHint,
                totalPercent >= 100 && styles.warningText,
              ]}
            >
              {totalPercent >= 100
                ? "已超過本月總預算，請留意支出。"
                : `已使用 ${totalPercent}%`}
            </Text>
          </>
        ) : (
          <Pressable onPress={onBudget} style={styles.dashedButton}>
            <Text style={styles.dashedButtonText}>設定每月總預算</Text>
          </Pressable>
        )}
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <View>
            <Text style={styles.cardTitle}>出遊規劃</Text>
            <Text style={styles.cardHint}>獨立於每月預算</Text>
          </View>
          <Pressable onPress={onTravelPlan} style={styles.outlineIconButton}>
            <MaterialCommunityIcons name="map-plus" size={18} color={palette.rose} />
          </Pressable>
        </View>
        {travelPlans.length === 0 ? (
          <EmptyInline text="安排旅行或聚會預算，日期範圍不會影響每月預算。" />
        ) : (
          travelPlans.map(plan => (
            <View key={plan.id} style={styles.travelPlanRow}>
              <View style={styles.travelPlanIcon}>
                <MaterialCommunityIcons name="map-marker-path" size={18} color={palette.rose} />
              </View>
              <View style={styles.memberPaymentName}>
                <Text style={styles.rowTitle}>{plan.name}</Text>
                <Text style={styles.rowSubtitle}>{dateKey(plan.startDate)} 至 {dateKey(plan.endDate)} · {money(plan.budget)}</Text>
                {!!plan.notes && <Text style={styles.rowSubtitle}>{plan.notes}</Text>}
              </View>
              <Pressable onPress={() => onDeleteTravelPlan(plan.id)} style={styles.rowActionButton} accessibilityLabel={`刪除${plan.name}`}>
                <MaterialCommunityIcons name="trash-can-outline" size={17} color={palette.rose} />
              </Pressable>
            </View>
          ))
        )}
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <Text style={styles.cardTitle}>分類預算</Text>
          <Text style={styles.cardHint}>
            {budgets.filter(item => item.categoryId !== 0).length} 項
          </Text>
        </View>
        {budgets
          .filter(item => item.categoryId !== 0)
          .map(budget => {
            const category = categories.find(
              item => item.id === budget.categoryId
            );
            const amount =
              analytics?.categories.find(item => item.id === budget.categoryId)
                ?.amount || 0;
            const percent = Math.min(
              100,
              Math.round((amount / budget.amount) * 100)
            );
            return (
              <View key={budget.id} style={styles.budgetRow}>
                <View style={styles.barLabelRow}>
                  <Text style={styles.rowTitle}>
                    {category?.icon || "◌"} {category?.name || "分類"}
                  </Text>
                  <Text style={styles.rowAmount}>
                    {money(amount)} / {money(budget.amount)}
                  </Text>
                </View>
                <View style={styles.barTrack}>
                  <View
                    style={[
                      styles.barFill,
                      {
                        width: `${Math.max(percent ? 5 : 0, percent)}%`,
                        backgroundColor:
                          percent >= 100 ? "#C25C5C" : palette.sage,
                      },
                    ]}
                  />
                </View>
              </View>
            );
          })}
        {budgets.filter(item => item.categoryId !== 0).length === 0 && (
          <EmptyInline text="尚未設定分類預算。" />
        )}
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <Text style={styles.cardTitle}>固定收支</Text>
          <Pressable onPress={onRecurring} style={styles.outlineIconButton}>
            <MaterialCommunityIcons name="plus" size={18} color={palette.rose} />
          </Pressable>
        </View>
        {recurring.length === 0 ? (
          <EmptyInline text="沒有固定收入或支出；新增後會在每月開啟帳本時自動補記。" />
        ) : (
          recurring.map(item => (
            <View key={item.id} style={styles.recurringRow}>
              <View style={styles.recurringIcon}>
                <MaterialCommunityIcons
                  name={item.type === "expense" ? "cash-minus" : "cash-plus"}
                  size={18}
                  color={item.type === "expense" ? palette.rose : palette.sage}
                />
              </View>
              <View style={styles.memberPaymentName}>
                <Text style={styles.rowTitle}>{item.title}</Text>
                <Text style={styles.rowSubtitle}>
                  {item.frequency === "monthly"
                    ? `每月 ${item.dayOfMonth} 日`
                    : item.frequency === "weekly"
                      ? "每週"
                      : "每年"}
                </Text>
              </View>
              <Text style={styles.rowAmount}>
                {item.type === "expense" ? "-" : "+"}
                {money(item.amount)}
              </Text>
            </View>
          ))
        )}
      </View>
    </>
  );
}

function PersonalSettingsPage({
  user,
  error,
  onUpdateNickname,
  onLogout,
  onBack,
}: {
  user: User;
  error: string;
  onUpdateNickname: (name: string) => void | Promise<void>;
  onLogout: () => void;
  onBack: () => void;
}) {
  const { preferences, palette, updatePreferences } = useAppearance();
  const [nickname, setNickname] = useState(user.name || "");
  const themes: Array<{ key: AppearanceTheme; label: string; color: string; icon: keyof typeof MaterialCommunityIcons.glyphMap }> = [
    { key: "rose", label: "玫瑰", color: "#B56C78", icon: "flower-outline" },
    { key: "graphite", label: "石墨", color: "#58677A", icon: "hexagon-outline" },
    { key: "latte", label: "拿鐵", color: "#B87955", icon: "coffee-outline" },
    { key: "mint", label: "薄荷", color: "#4D9381", icon: "leaf" },
    { key: "ocean", label: "海洋", color: "#397D9B", icon: "waves" },
    { key: "sunset", label: "夕暮", color: "#D17B61", icon: "weather-sunset" },
    { key: "starry", label: "星空", color: "#6D63B8", icon: "star-four-points" },
    { key: "forest", label: "森林", color: "#5A956F", icon: "pine-tree" },
    { key: "lavender", label: "薰衣草", color: "#9C6BB3", icon: "flower-tulip-outline" },
  ];
  const fonts: Array<{ key: AppearanceFont; label: string; preview: string }> = [
    { key: "system", label: "系統", preview: "Aa" },
    { key: "rounded", label: "圓體", preview: "Aa" },
    { key: "serif", label: "襯線", preview: "Aa" },
    { key: "clean", label: "清爽細字", preview: "Aa" },
    { key: "mono", label: "等寬", preview: "Aa" },
  ];
  const scales: Array<{ key: AppearanceScale; label: string }> = [
    { key: "tiny", label: "特小" },
    { key: "small", label: "小" },
    { key: "standard", label: "標準" },
    { key: "large", label: "大" },
    { key: "xl", label: "特大" },
  ];
  const cardStyles: Array<{ key: AppearanceCardStyle; label: string; icon: keyof typeof MaterialCommunityIcons.glyphMap; hint: string }> = [
    { key: "soft", label: "柔和卡片", icon: "card-outline", hint: "圓角與柔和層次" },
    { key: "outlined", label: "清晰邊框", icon: "border-all", hint: "邊界更明確" },
    { key: "flat", label: "純淨平面", icon: "view-agenda-outline", hint: "減少卡片框線" },
  ];
  const navStyles: Array<{ key: AppearanceNavStyle; label: string; icon: keyof typeof MaterialCommunityIcons.glyphMap }> = [
    { key: "pill", label: "膠囊選取", icon: "view-dashboard-outline" },
    { key: "line", label: "底線選取", icon: "format-align-bottom" },
    { key: "minimal", label: "極簡導覽", icon: "dots-horizontal" },
  ];
  return (
    <SafeAreaView style={[styles.screen, { backgroundColor: palette.background }]} edges={["bottom"]}>
      <ScrollView contentContainerStyle={styles.profileContent}>
        <SectionIntro
          eyebrow="YOUR SPACE"
          title="把共帳調成你的樣子"
          body="這些偏好只會影響你的裝置，不會改變共同帳本資料。"
        />
        {!!error && <Text style={styles.globalError}>{error}</Text>}
        <View style={styles.card}>
          <View style={styles.cardHeading}>
        <View style={styles.personalizationHeading}>
          <MaterialCommunityIcons name="account-cog-outline" size={19} color={palette.rose} />
          <Text style={styles.cardTitle}>個人設定</Text>
        </View>
        <Text style={styles.cardHint}>主頁可調整</Text>
      </View>
      <Text style={styles.cardHint}>主題、字體與版型會立即套用並保存在這台裝置；共同帳本資料不會因此改變。</Text>
      <Text style={styles.personalizationLabel}>使用者暱稱</Text>
      <TextInput
        value={nickname}
        onChangeText={setNickname}
        placeholder="輸入你想顯示的暱稱"
        placeholderTextColor={colors.muted}
        maxLength={64}
        returnKeyType="done"
        style={styles.input}
      />
      <Pressable
        onPress={() => void onUpdateNickname(nickname)}
        style={({ pressed }) => [styles.smallButton, pressed && styles.pressed]}
      >
        <Text style={styles.smallButtonText}>儲存暱稱</Text>
      </Pressable>
      <Text style={styles.rowSubtitle}>
        暱稱會顯示在帳本成員與操作日誌中。
      </Text>
      <Text style={styles.personalizationLabel}>App 主題</Text>
      <View style={styles.themeGrid}>
        {themes.map(theme => (
          <Pressable
            key={theme.key}
            onPress={() => updatePreferences({ theme: theme.key })}
            style={[
              styles.themeOption,
              preferences.theme === theme.key && styles.appearanceOptionActive,
            ]}
          >
            <View style={[styles.themePreview, { backgroundColor: theme.color }]}>
              <MaterialCommunityIcons name={theme.icon} size={19} color="#FFFFFF" />
              {theme.key === "starry" && <Text style={styles.themePreviewSparkle}>✦</Text>}
              {theme.key === "forest" && <View style={styles.themePreviewLake} />}
            </View>
            <Text style={styles.appearanceOptionText}>{theme.label}</Text>
          </Pressable>
        ))}
      </View>
      <Text style={styles.personalizationLabel}>字體</Text>
      <View style={styles.optionRow}>
        {fonts.map(font => (
          <Pressable
            key={font.key}
            onPress={() => updatePreferences({ font: font.key })}
            style={[
              styles.appearanceOption,
              preferences.font === font.key && styles.appearanceOptionActive,
            ]}
          >
            <Text style={[styles.fontPreview, { fontFamily: appearanceFontMap[font.key] }]}>{font.preview}</Text>
            <Text style={styles.appearanceOptionText}>{font.label}</Text>
          </Pressable>
        ))}
      </View>
      <Text style={styles.personalizationLabel}>文字大小</Text>
      <View style={styles.optionRow}>
        {scales.map(scale => (
          <Pressable
            key={scale.key}
            onPress={() => updatePreferences({ scale: scale.key })}
            style={[
              styles.appearanceOption,
              preferences.scale === scale.key && styles.appearanceOptionActive,
            ]}
          >
            <Text style={styles.appearanceOptionText}>{scale.label}</Text>
          </Pressable>
        ))}
      </View>
      <Text style={styles.personalizationLabel}>介面卡片樣式</Text>
      <View style={styles.appearanceGrid}>
        {cardStyles.map(option => (
          <Pressable
            key={option.key}
            accessibilityRole="button"
            accessibilityLabel={`選擇${option.label}`}
            onPress={() => updatePreferences({ cardStyle: option.key })}
            style={[
              styles.appearanceStyleOption,
              preferences.cardStyle === option.key && styles.appearanceOptionActive,
            ]}
          >
            <View style={[
              styles.cardStylePreview,
              option.key === "soft" && styles.cardStylePreviewSoft,
              option.key === "outlined" && styles.cardStylePreviewOutlined,
              option.key === "flat" && styles.cardStylePreviewFlat,
            ]}>
              <View style={styles.cardStylePreviewLine} />
              <View style={[styles.cardStylePreviewLine, styles.cardStylePreviewLineShort]} />
            </View>
            <MaterialCommunityIcons name={option.icon} size={18} color={palette.rose} />
            <View style={styles.appearanceStyleCopy}>
              <Text style={styles.appearanceOptionText}>{option.label}</Text>
              <Text style={styles.appearanceStyleHint}>{option.hint}</Text>
            </View>
          </Pressable>
        ))}
      </View>
      <Text style={styles.personalizationLabel}>底部導覽樣式</Text>
      <View style={styles.optionRow}>
        {navStyles.map(option => (
          <Pressable
            key={option.key}
            accessibilityRole="button"
            accessibilityLabel={`選擇${option.label}`}
            onPress={() => updatePreferences({ navStyle: option.key })}
            style={[
              styles.appearanceOption,
              preferences.navStyle === option.key && styles.appearanceOptionActive,
            ]}
          >
            <View style={[styles.navStylePreview, option.key === "line" && styles.navStylePreviewLine, option.key === "minimal" && styles.navStylePreviewMinimal]}>
              <View style={styles.navStylePreviewDot} />
              <View style={styles.navStylePreviewDot} />
              <View style={styles.navStylePreviewDot} />
            </View>
            <MaterialCommunityIcons name={option.icon} size={17} color={palette.rose} />
            <Text style={styles.appearanceOptionText}>{option.label}</Text>
          </Pressable>
        ))}
      </View>
      <View style={styles.preferenceRow}>
        <View style={styles.preferenceCopy}>
          <Text style={styles.rowTitle}>緊湊清單</Text>
          <Text style={styles.rowSubtitle}>讓交易與帳本列表顯示更多內容</Text>
        </View>
        <Switch value={preferences.compactMode} onValueChange={value => updatePreferences({ compactMode: value })} trackColor={{ false: palette.border, true: palette.roseSoft }} thumbColor={preferences.compactMode ? palette.rose : palette.muted} />
      </View>
      <View style={styles.preferenceRow}>
        <View style={styles.preferenceCopy}>
          <Text style={styles.rowTitle}>減少動態效果</Text>
          <Text style={styles.rowSubtitle}>降低切換時的視覺動態，適合需要穩定畫面時使用</Text>
        </View>
        <Switch value={preferences.reduceMotion} onValueChange={value => updatePreferences({ reduceMotion: value })} trackColor={{ false: palette.border, true: palette.roseSoft }} thumbColor={preferences.reduceMotion ? palette.rose : palette.muted} />
      </View>
      <View style={styles.preferenceRow}>
        <View style={styles.preferenceCopy}>
          <Text style={styles.rowTitle}>掃描自動填入摘要</Text>
          <Text style={styles.rowSubtitle}>辨識到店家或品項時，自動放入備註欄</Text>
        </View>
        <Switch value={preferences.autoReceiptNote} onValueChange={value => updatePreferences({ autoReceiptNote: value })} trackColor={{ false: palette.border, true: palette.roseSoft }} thumbColor={preferences.autoReceiptNote ? palette.rose : palette.muted} />
      </View>
      <Pressable
        onPress={onLogout}
        style={({ pressed }) => [styles.outlineButton, pressed && styles.pressed]}
      >
        <MaterialCommunityIcons name="logout" size={17} color={palette.rose} />
        <Text style={styles.outlineButtonText}>登出帳號</Text>
      </Pressable>
      <Pressable onPress={onBack} style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]}>
        <MaterialCommunityIcons name="arrow-left" size={17} color={palette.rose} />
        <Text style={styles.secondaryButtonText}>返回我的帳本</Text>
      </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function SettingsSection({
  ledger,
  user,
  members,
  categories,
  paymentMethods,
  history,
  activityLogs,
  onCategory,
  onPayment,
  onArchiveCategory,
  onArchivePayment,
  onRefresh,
  onLeaveLedger,
  onRenameLedger,
  onTransferOwnership,
  onRoleChange,
}: {
  ledger: Ledger;
  user: User;
  members: LedgerMember[];
  categories: Category[];
  paymentMethods: PaymentMethod[];
    history: SettlementHistory[];
  activityLogs: ActivityLog[];
  onCategory: () => void;
  onPayment: () => void;
  onArchiveCategory: (categoryId: number) => void;
  onArchivePayment: (paymentMethodId: number) => void;
  onRefresh: () => void;
  onLeaveLedger: () => void;
  onRenameLedger: () => void;
  onTransferOwnership: () => void;
  onRoleChange: (memberId: number, role: "admin" | "member" | "viewer") => void;
}) {
  const { palette } = useAppearance();
  const [showQr, setShowQr] = useState(false);
  const [copied, setCopied] = useState(false);
  const me = members.find(item => item.user.id === user.id);
  const isAdmin = me?.member.role === "admin";
  const inviteLink = `togetherledger://join?code=${ledger.inviteCode}`;
  const shareInvite = async () => {
    await Share.share({
      message: `加入我的共帳「${ledger.name}」\n邀請碼：${ledger.inviteCode}\n邀請連結：${inviteLink}`,
    });
  };
  const copyInviteCode = async () => {
    await Clipboard.setStringAsync(ledger.inviteCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };
  const addPresets = async () => {
    const presets = [
      { name: "飲食", icon: "food", type: "expense" as const },
      { name: "交通", icon: "car", type: "expense" as const },
      { name: "生活", icon: "home", type: "expense" as const },
      { name: "購物", icon: "shopping", type: "expense" as const },
      { name: "情侶", icon: "heart", type: "expense" as const },
      { name: "薪資", icon: "income", type: "income" as const },
    ];
    for (const preset of presets.filter(
      item =>
        !categories.some(
          category => category.name === item.name && category.type === item.type
        )
    ))
      await api.ledger.createCategory.mutate({
        ledgerId: ledger.id,
        parentCategoryId: 0,
        name: preset.name,
        type: preset.type,
        icon: preset.icon,
        color: palette.rose,
      });
    onRefresh();
  };
  const addPaymentPresets = async () => {
    const presets = [
      { name: "現金", icon: "cash" },
      { name: "信用卡", icon: "card" },
      { name: "電子支付", icon: "pay" },
      { name: "銀行轉帳", icon: "bank" },
    ];
    for (const preset of presets.filter(
      item => !paymentMethods.some(method => method.name === item.name)
    ))
      await api.ledger.createPaymentMethod.mutate({
        ledgerId: ledger.id,
        ...preset,
      });
    onRefresh();
  };
  const [categoryQuery, setCategoryQuery] = useState("");
  const [paymentQuery, setPaymentQuery] = useState("");
  const [showInactiveCategories, setShowInactiveCategories] = useState(false);
  const [showInactivePayments, setShowInactivePayments] = useState(false);
  const [showAllCategories, setShowAllCategories] = useState(false);
  const [showAllPayments, setShowAllPayments] = useState(false);
  const [categorySort, setCategorySort] = useState<"name" | "status">("name");
  const [paymentSort, setPaymentSort] = useState<"name" | "status">("name");
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingPayment, setEditingPayment] = useState<PaymentMethod | null>(null);
  const [draftCategoryName, setDraftCategoryName] = useState("");
  const [draftCategoryIcon, setDraftCategoryIcon] = useState("");
  const [draftCategoryType, setDraftCategoryType] = useState<"expense" | "income">("expense");
  const [draftPaymentName, setDraftPaymentName] = useState("");
  const [draftPaymentIcon, setDraftPaymentIcon] = useState("");
  const [settingsBusy, setSettingsBusy] = useState(false);
  const visibleCategories = [...categories]
    .filter(item => {
      const matchesQuery = `${item.name} ${item.icon}`.toLowerCase().includes(categoryQuery.trim().toLowerCase());
      return matchesQuery && (showInactiveCategories || item.isActive !== 0);
    })
    .sort((left, right) =>
      categorySort === "status"
        ? Number(right.isActive || 0) - Number(left.isActive || 0) || left.name.localeCompare(right.name, "zh-Hant")
        : left.name.localeCompare(right.name, "zh-Hant")
    );
  const visiblePayments = [...paymentMethods]
    .filter(item => {
      const matchesQuery = `${item.name} ${item.icon}`.toLowerCase().includes(paymentQuery.trim().toLowerCase());
      return matchesQuery && (showInactivePayments || item.isActive !== 0);
    })
    .sort((left, right) =>
      paymentSort === "status"
        ? Number(right.isActive || 0) - Number(left.isActive || 0) || left.name.localeCompare(right.name, "zh-Hant")
        : left.name.localeCompare(right.name, "zh-Hant")
    );
  const displayedCategories = categoryQuery.trim() || showAllCategories
    ? visibleCategories
    : visibleCategories.slice(0, 6);
  const displayedPayments = paymentQuery.trim() || showAllPayments
    ? visiblePayments
    : visiblePayments.slice(0, 6);
  const startEditCategory = (item: Category) => {
    setEditingCategory(item);
    setDraftCategoryName(item.name);
    setDraftCategoryIcon(item.icon);
    setDraftCategoryType(item.type);
  };
  const startEditPayment = (item: PaymentMethod) => {
    setEditingPayment(item);
    setDraftPaymentName(item.name);
    setDraftPaymentIcon(item.icon);
  };
  const saveCategory = async () => {
    if (!editingCategory || !draftCategoryName.trim()) return;
    setSettingsBusy(true);
    try {
      await api.ledger.updateCategory.mutate({ ledgerId: ledger.id, categoryId: editingCategory.id, name: draftCategoryName.trim(), icon: draftCategoryIcon.trim() || "◌", type: draftCategoryType, color: editingCategory.color });
      setEditingCategory(null);
      onRefresh();
    } finally {
      setSettingsBusy(false);
    }
  };
  const savePayment = async () => {
    if (!editingPayment || !draftPaymentName.trim()) return;
    setSettingsBusy(true);
    try {
      await api.ledger.updatePaymentMethod.mutate({ ledgerId: ledger.id, paymentMethodId: editingPayment.id, name: draftPaymentName.trim(), icon: draftPaymentIcon.trim() || "💳" });
      setEditingPayment(null);
      onRefresh();
    } finally {
      setSettingsBusy(false);
    }
  };
  const restoreCategory = async (item: Category) => {
    await api.ledger.setCategoryActive.mutate({ ledgerId: ledger.id, categoryId: item.id, isActive: 1 });
    onRefresh();
  };
  const restorePayment = async (item: PaymentMethod) => {
    await api.ledger.setPaymentMethodActive.mutate({ ledgerId: ledger.id, paymentMethodId: item.id, isActive: 1 });
    onRefresh();
  };
  return (
    <>
      <SectionIntro
        eyebrow="LEDGER SETTINGS"
        title="把共同空間設定好"
        body="帳本不會預先建立交易、預算或固定收支；分類與支付方式支援完整自訂或重置。"
      />
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <View style={styles.personalizationHeading}>
            <MaterialCommunityIcons name="account-switch-outline" size={19} color={palette.rose} />
            <Text style={styles.cardTitle}>帳本管理</Text>
          </View>
        </View>
        <Text style={styles.rowSubtitle}>名稱、持有者與成員權限可以分開管理，避免為了交接而被迫退出。</Text>
        <View style={styles.settingsActionGrid}>
          <Pressable onPress={onRenameLedger} style={styles.settingsActionButton}>
            <MaterialCommunityIcons name="pencil-outline" size={17} color={palette.rose} />
            <Text style={styles.settingsActionText}>修改帳本名稱</Text>
          </Pressable>
          {isAdmin && members.length > 1 && (
            <Pressable onPress={onTransferOwnership} style={styles.settingsActionButton}>
              <MaterialCommunityIcons name="account-switch-outline" size={17} color={palette.rose} />
              <Text style={styles.settingsActionText}>直接轉讓所有權</Text>
            </Pressable>
          )}
        </View>
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <View style={styles.personalizationHeading}>
            <MaterialCommunityIcons name="exit-to-app" size={19} color={palette.rose} />
            <Text style={styles.cardTitle}>帳本生命週期</Text>
          </View>
        </View>
        <Text style={styles.rowSubtitle}>
          成員可退出帳本；持有者需要先轉讓給其他成員，或確認刪除整本帳本。
        </Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="退出或移除目前帳本"
          onPress={onLeaveLedger}
          style={({ pressed }) => [styles.dangerButton, pressed && styles.pressed]}
        >
          <MaterialCommunityIcons name="exit-to-app" size={18} color={palette.rose} />
          <Text style={styles.dangerButtonText}>退出／移除目前帳本</Text>
        </Pressable>
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <Text style={styles.cardTitle}>邀請成員</Text>
          <Pressable onPress={shareInvite} style={styles.outlineIconButton}>
            <MaterialCommunityIcons
              name="share-variant"
              size={18}
              color={palette.rose}
            />
          </Pressable>
        </View>
        <Pressable
          accessibilityLabel="複製邀請碼"
          accessibilityRole="button"
          onPress={copyInviteCode}
          style={({ pressed }) => [styles.inviteCodeCopy, pressed && styles.pressed]}
        >
          <Text style={styles.inviteCodeLarge}>{ledger.inviteCode}</Text>
          <View style={styles.inviteCopyHint}>
            <MaterialCommunityIcons name={copied ? "check-circle-outline" : "content-copy"} size={16} color={palette.rose} />
            <Text style={styles.inviteCopyHintText}>{copied ? "已複製邀請碼" : "點擊複製"}</Text>
          </View>
        </Pressable>
        <Text style={styles.rowSubtitle}>
          邀請碼可分享給伴侶、室友或家人；也支援 deep link 邀請。
        </Text>
        <Pressable
          onPress={() => setShowQr(value => !value)}
          style={styles.dashedButton}
        >
          <MaterialCommunityIcons name="qrcode" size={17} color={palette.rose} />
          <Text style={styles.dashedButtonText}>
            {showQr ? "收起 QR Code" : "顯示 QR Code"}
          </Text>
        </Pressable>
        {showQr && (
          <View style={styles.qrWrap}>
            <QRCode
              value={inviteLink}
              size={156}
              color={palette.ink}
              backgroundColor={palette.surface}
            />
            <Text style={styles.qrCaption}>{inviteLink}</Text>
          </View>
        )}
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <Text style={styles.cardTitle}>成員與權限</Text>
          <Text style={styles.cardHint}>{members.length} 位</Text>
        </View>
        <Text style={styles.rowSubtitle}>
          支援管理員、可編輯成員與檢視者；目前不提供任意自訂權限組合。
        </Text>
        {members.map(item => (
          <View key={item.user.id} style={styles.memberPaymentRow}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>
                {(item.user.name || item.user.email || "成").slice(0, 1)}
              </Text>
            </View>
            <View style={styles.memberPaymentName}>
              <Text style={styles.rowTitle}>
                {item.user.id === user.id
                  ? "你"
                  : item.user.name || item.user.email || "成員"}
              </Text>
              <Text style={styles.rowSubtitle}>
                {item.member.role === "admin"
                  ? "管理員"
                  : item.member.role === "viewer"
                    ? "檢視者"
                    : "可編輯成員"}
              </Text>
            </View>
            {isAdmin && item.user.id !== user.id ? (
              <Pressable
                onPress={() =>
                  onRoleChange(
                    item.user.id,
                    item.member.role === "member"
                      ? "admin"
                      : item.member.role === "admin"
                        ? "viewer"
                        : "member"
                  )
                }
                style={styles.rolePill}
              >
                <Text style={styles.rolePillText}>
                  {item.member.role === "member"
                    ? "設為管理員"
                    : item.member.role === "admin"
                      ? "改檢視"
                      : "允許編輯"}
                </Text>
              </Pressable>
            ) : (
              <MaterialCommunityIcons
                name="shield-account-outline"
                size={20}
                color={palette.muted}
              />
            )}
          </View>
        ))}
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <View style={styles.personalizationHeading}>
            <MaterialCommunityIcons name="shape-outline" size={19} color={palette.rose} />
            <Text style={styles.cardTitle}>分類管理</Text>
          </View>
          <Pressable onPress={onCategory} style={styles.outlineIconButton} accessibilityLabel="新增分類">
            <MaterialCommunityIcons name="plus" size={18} color={palette.rose} />
          </Pressable>
        </View>
        <TextInput value={categoryQuery} onChangeText={setCategoryQuery} placeholder="搜尋分類名稱或圖示" placeholderTextColor={palette.muted} style={styles.input} />
        <View style={styles.settingsFilterRow}>
          <Text style={styles.rowSubtitle}>{visibleCategories.length} 個項目</Text>
          <View style={styles.settingsFilterActions}>
            <Pressable onPress={() => setCategorySort(value => value === "name" ? "status" : "name")} style={styles.settingsFilterButton} accessibilityLabel="切換分類排序">
              <MaterialCommunityIcons name="sort-variant" size={15} color={palette.rose} />
              <Text style={styles.settingsFilterText}>{categorySort === "name" ? "依名稱" : "依狀態"}</Text>
            </Pressable>
            <Pressable onPress={() => setShowInactiveCategories(value => !value)} style={styles.settingsFilterButton}>
              <MaterialCommunityIcons name={showInactiveCategories ? "eye-off-outline" : "eye-outline"} size={15} color={palette.rose} />
              <Text style={styles.settingsFilterText}>{showInactiveCategories ? "隱藏停用" : "顯示停用"}</Text>
            </Pressable>
          </View>
        </View>
        {categories.length === 0 ? (
          <>
            <EmptyInline text="目前沒有分類。" />
            <Pressable onPress={addPresets} style={styles.dashedButton}>
              <Text style={styles.dashedButtonText}>加入預設分類建議</Text>
            </Pressable>
          </>
        ) : visibleCategories.length === 0 ? (
          <EmptyInline text="找不到符合的分類，或目前沒有啟用項目。" />
        ) : (
          <View style={styles.settingsList}>
            {displayedCategories.map(item => (
              <View key={item.id} style={styles.settingsListRow}>
                <View style={styles.settingsListIcon}>
                  <MaterialCommunityIcons name={categorySystemIcon(item)} size={18} color={palette.rose} />
                </View>
                <View style={styles.memberPaymentName}>
                  <Text style={styles.rowTitle}>{item.name}</Text>
                  <Text style={styles.rowSubtitle}>{item.type === "expense" ? "支出分類" : "收入分類"}{item.isActive === 0 ? " · 已停用" : ""}</Text>
                </View>
                {isAdmin && <>
                  <Pressable onPress={() => startEditCategory(item)} style={styles.outlineIconButton} accessibilityLabel={`編輯分類 ${item.name}`}>
                    <MaterialCommunityIcons name="pencil-outline" size={17} color={palette.rose} />
                  </Pressable>
                  <Pressable onPress={() => item.isActive === 0 ? restoreCategory(item) : onArchiveCategory(item.id)} style={styles.outlineIconButton} accessibilityLabel={item.isActive === 0 ? `恢復分類 ${item.name}` : `停用分類 ${item.name}`}>
                    <MaterialCommunityIcons name={item.isActive === 0 ? "restore" : "archive-outline"} size={17} color={palette.rose} />
                  </Pressable>
                </>}
              </View>
            ))}
            {visibleCategories.length > 6 && !categoryQuery.trim() && (
              <Pressable onPress={() => setShowAllCategories(value => !value)} style={styles.compactListToggle}>
                <MaterialCommunityIcons name={showAllCategories ? "chevron-up" : "chevron-down"} size={17} color={palette.rose} />
                <Text style={styles.compactListToggleText}>{showAllCategories ? "收合分類" : `查看其餘 ${visibleCategories.length - 6} 個分類`}</Text>
              </Pressable>
            )}
          </View>
        )}
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <View style={styles.personalizationHeading}>
            <MaterialCommunityIcons name="credit-card-settings-outline" size={19} color={palette.rose} />
            <Text style={styles.cardTitle}>支付方式管理</Text>
          </View>
          <Pressable onPress={onPayment} style={styles.outlineIconButton} accessibilityLabel="新增支付方式">
            <MaterialCommunityIcons name="plus" size={18} color={palette.rose} />
          </Pressable>
        </View>
        <TextInput value={paymentQuery} onChangeText={setPaymentQuery} placeholder="搜尋支付方式或圖示" placeholderTextColor={palette.muted} style={styles.input} />
        <View style={styles.settingsFilterRow}>
          <Text style={styles.rowSubtitle}>{visiblePayments.length} 個項目</Text>
          <View style={styles.settingsFilterActions}>
            <Pressable onPress={() => setPaymentSort(value => value === "name" ? "status" : "name")} style={styles.settingsFilterButton} accessibilityLabel="切換支付方式排序">
              <MaterialCommunityIcons name="sort-variant" size={15} color={palette.rose} />
              <Text style={styles.settingsFilterText}>{paymentSort === "name" ? "依名稱" : "依狀態"}</Text>
            </Pressable>
            <Pressable onPress={() => setShowInactivePayments(value => !value)} style={styles.settingsFilterButton}>
              <MaterialCommunityIcons name={showInactivePayments ? "eye-off-outline" : "eye-outline"} size={15} color={palette.rose} />
              <Text style={styles.settingsFilterText}>{showInactivePayments ? "隱藏停用" : "顯示停用"}</Text>
            </Pressable>
          </View>
        </View>
        {paymentMethods.length === 0 ? (
          <>
            <EmptyInline text="目前沒有支付方式。" />
            <Pressable onPress={addPaymentPresets} style={styles.dashedButton}>
              <Text style={styles.dashedButtonText}>加入常用支付方式建議</Text>
            </Pressable>
          </>
        ) : visiblePayments.length === 0 ? (
          <EmptyInline text="找不到符合的支付方式，或目前沒有啟用項目。" />
        ) : (
          <View style={styles.settingsList}>
            {displayedPayments.map(item => (
              <View key={item.id} style={styles.settingsListRow}>
                <View style={styles.settingsListIcon}>
                  <MaterialCommunityIcons name={paymentSystemIcon(item)} size={18} color={palette.rose} />
                </View>
                <View style={styles.memberPaymentName}>
                  <Text style={styles.rowTitle}>{item.name}</Text>
                  <Text style={styles.rowSubtitle}>{item.isActive === 0 ? "已停用" : "可用於新增收支"}</Text>
                </View>
                {isAdmin && <>
                  <Pressable onPress={() => startEditPayment(item)} style={styles.outlineIconButton} accessibilityLabel={`編輯支付方式 ${item.name}`}>
                    <MaterialCommunityIcons name="pencil-outline" size={17} color={palette.rose} />
                  </Pressable>
                  <Pressable onPress={() => item.isActive === 0 ? restorePayment(item) : onArchivePayment(item.id)} style={styles.outlineIconButton} accessibilityLabel={item.isActive === 0 ? `恢復支付方式 ${item.name}` : `停用支付方式 ${item.name}`}>
                    <MaterialCommunityIcons name={item.isActive === 0 ? "restore" : "archive-outline"} size={17} color={palette.rose} />
                  </Pressable>
                </>}
              </View>
            ))}
            {visiblePayments.length > 6 && !paymentQuery.trim() && (
              <Pressable onPress={() => setShowAllPayments(value => !value)} style={styles.compactListToggle}>
                <MaterialCommunityIcons name={showAllPayments ? "chevron-up" : "chevron-down"} size={17} color={palette.rose} />
                <Text style={styles.compactListToggleText}>{showAllPayments ? "收合支付方式" : `查看其餘 ${visiblePayments.length - 6} 個支付方式`}</Text>
              </Pressable>
            )}
          </View>
        )}
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <Text style={styles.cardTitle}>操作日誌</Text>
          <Text style={styles.cardHint}>{activityLogs.length} 筆</Text>
        </View>
        {activityLogs.length === 0 ? <EmptyInline text="尚未有操作紀錄。" /> : <ScrollView style={styles.activityLogScroll} nestedScrollEnabled>
          {activityLogs.slice(0, 100).map(log => (
            <View key={log.log.id} style={styles.activityLogRow}>
              <View style={styles.activityLogDot} />
              <View style={styles.memberPaymentName}>
                <Text style={styles.rowTitle}>{log.log.summary || `${log.log.action} ${log.log.entityType}`}</Text>
                <Text style={styles.rowSubtitle}>{log.user.name || log.user.email || "成員"} · {new Date(log.log.createdAt).toLocaleString("zh-TW")}</Text>
              </View>
            </View>
          ))}
        </ScrollView>}
      </View>
      <View style={styles.card}>
        <View style={styles.cardHeading}>
          <Text style={styles.cardTitle}>結算紀錄</Text>
          <Text style={styles.cardHint}>{history.length} 筆</Text>
        </View>
        {history.length === 0 ? (
          <EmptyInline text="尚未有已結算紀錄。" />
        ) : (
          history.slice(0, 6).map(item => {
            const from = members.find(member => member.user.id === item.fromUserId)?.user;
            const to = members.find(member => member.user.id === item.toUserId)?.user;
            return (
              <View key={item.id} style={styles.historyRow}>
                <View style={styles.historyIcon}>
                  <MaterialCommunityIcons name="check" size={16} color={palette.sage} />
                </View>
                <View style={styles.memberPaymentName}>
                  <Text style={styles.rowTitle}>{monthLabel(item.month)} 已結算</Text>
                  <Text style={styles.rowSubtitle}>
                    {from?.name || from?.email || "成員"} → {to?.name || to?.email || "成員"}
                  </Text>
                </View>
                <Text style={styles.historyAmount}>{money(item.amount)}</Text>
              </View>
            );
          })
        )}
            </View>
      <Modal visible={Boolean(editingCategory)} transparent animationType="slide" onRequestClose={() => setEditingCategory(null)}>
        <View style={styles.modalBackdrop}>
          <Pressable style={styles.modalDismiss} onPress={() => setEditingCategory(null)} />
          <View style={styles.modalCard}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>編輯分類</Text>
            <Text style={styles.modalDescription}>修改名稱或圖示不會影響既有收支紀錄。</Text>
            <TextInput value={draftCategoryName} onChangeText={setDraftCategoryName} placeholder="分類名稱" placeholderTextColor={palette.muted} style={styles.input} />
            <TextInput value={draftCategoryIcon} onChangeText={setDraftCategoryIcon} placeholder="圖示，例如 🍜" placeholderTextColor={palette.muted} style={styles.input} />
            <View style={styles.segmentRow}>
              {(["expense", "income"] as const).map(item => (
                <Pressable key={item} onPress={() => setDraftCategoryType(item)} style={[styles.segment, draftCategoryType === item && styles.segmentActive]}>
                  <Text style={[styles.segmentText, draftCategoryType === item && styles.segmentTextActive]}>{item === "expense" ? "支出分類" : "收入分類"}</Text>
                </Pressable>
              ))}
            </View>
            <View style={styles.confirmActions}>
              <Pressable onPress={() => setEditingCategory(null)} style={[styles.confirmCancel, { borderColor: palette.border }]}>
                <Text style={[styles.confirmCancelText, { color: palette.muted }]}>取消</Text>
              </Pressable>
              <Pressable disabled={settingsBusy || !draftCategoryName.trim()} onPress={saveCategory} style={[styles.confirmPrimary, { backgroundColor: palette.rose }, settingsBusy && styles.disabled]}>
                <Text style={styles.confirmPrimaryText}>{settingsBusy ? "儲存中…" : "儲存分類"}</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
      <Modal visible={Boolean(editingPayment)} transparent animationType="slide" onRequestClose={() => setEditingPayment(null)}>
        <View style={styles.modalBackdrop}>
          <Pressable style={styles.modalDismiss} onPress={() => setEditingPayment(null)} />
          <View style={styles.modalCard}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>編輯支付方式</Text>
            <Text style={styles.modalDescription}>修改名稱或圖示不會影響既有收支紀錄。</Text>
            <TextInput value={draftPaymentName} onChangeText={setDraftPaymentName} placeholder="支付方式名稱" placeholderTextColor={palette.muted} style={styles.input} />
            <TextInput value={draftPaymentIcon} onChangeText={setDraftPaymentIcon} placeholder="圖示，例如 💳" placeholderTextColor={palette.muted} style={styles.input} />
            <View style={styles.confirmActions}>
              <Pressable onPress={() => setEditingPayment(null)} style={[styles.confirmCancel, { borderColor: palette.border }]}>
                <Text style={[styles.confirmCancelText, { color: palette.muted }]}>取消</Text>
              </Pressable>
              <Pressable disabled={settingsBusy || !draftPaymentName.trim()} onPress={savePayment} style={[styles.confirmPrimary, { backgroundColor: palette.rose }, settingsBusy && styles.disabled]}>
                <Text style={styles.confirmPrimaryText}>{settingsBusy ? "儲存中…" : "儲存支付方式"}</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}
function SectionIntro({
  eyebrow,
  title,
  body,
}: {
  eyebrow: string;
  title: string;
  body: string;
}) {
  const { palette } = useAppearance();
  return (
    <View style={styles.sectionIntro}>
      <Text style={styles.eyebrow}>{eyebrow}</Text>
      <Text style={styles.sectionTitle}>{title}</Text>
      <Text style={styles.sectionBody}>{body}</Text>
    </View>
  );
}
function EmptyInline({ text }: { text: string }) {
  return (
    <View style={styles.emptyInline}>
      <MaterialCommunityIcons
        name="information-outline"
        size={18}
        color={colors.muted}
      />
      <Text style={styles.emptyInlineText}>{text}</Text>
    </View>
  );
}
function TransactionRow({
  transaction,
  categories,
  onEdit,
  onDelete,
}: {
  transaction: Transaction;
  categories: Category[];
  onEdit: (transaction: Transaction) => void;
  onDelete: (transaction: Transaction) => void;
}) {
  const { palette } = useAppearance();
  const category = categories.find(item => item.id === transaction.categoryId);
  return (
    <View style={styles.transactionRow}>
      <View
        style={[
          styles.transactionIcon,
          { backgroundColor: transaction.type === "income" ? "#E6F0E3" : palette.roseSoft },
        ]}
      >
        <MaterialCommunityIcons
          name={transaction.type === "income" ? "cash-plus" : "receipt-text-outline"}
          size={18}
          color={transaction.type === "income" ? palette.sage : palette.rose}
        />
      </View>
      <View style={styles.memberPaymentName}>
        <Text style={styles.rowTitle}>{category?.icon || "◌"} {category?.name || "未分類"}</Text>
        <Text style={styles.rowSubtitle}>{transaction.note || "共同收支"} · {dateKey(transaction.date)}</Text>
      </View>
      <Text style={[styles.rowAmount, transaction.type === "income" && styles.incomeText]}>
        {transaction.type === "income" ? "+" : "-"}{money(transaction.amount)}
      </Text>
      <View style={styles.transactionActions}>
        <Pressable accessibilityLabel="編輯收支" onPress={() => onEdit(transaction)} style={styles.rowActionButton}>
          <MaterialCommunityIcons name="pencil-outline" size={16} color={palette.muted} />
        </Pressable>
        <Pressable accessibilityLabel="移除收支" onPress={() => onDelete(transaction)} style={styles.rowActionButton}>
          <MaterialCommunityIcons name="trash-can-outline" size={16} color={palette.rose} />
        </Pressable>
      </View>
    </View>
  );
}

function QuickNav({
  active,
  onSelect,
}: {
  active: DrawerAction;
  onSelect: (action: DrawerAction) => void;
}) {
  const { palette, preferences } = useAppearance();
  const items: Array<{
    key: DrawerAction;
    label: string;
    icon: keyof typeof MaterialCommunityIcons.glyphMap;
  }> = [
    { key: "overview", label: "總覽", icon: "view-dashboard-outline" },
    { key: "calendar", label: "月曆", icon: "calendar-month-outline" },
    { key: "analysis", label: "分析", icon: "chart-line" },
    { key: "planning", label: "規劃", icon: "wallet-outline" },
    { key: "settings", label: "設定", icon: "tune-variant" },
  ];
  return (
    <View style={[
      styles.quickNav,
      preferences.navStyle === "pill" && styles.quickNavPill,
      preferences.navStyle === "line" && styles.quickNavLine,
      preferences.navStyle === "minimal" && styles.quickNavMinimal,
    ]}>
      {items.map(item => (
        <Pressable
          key={item.key}
          accessibilityRole="tab"
          accessibilityState={{ selected: active === item.key }}
          accessibilityLabel={`切換至${item.label}`}
          onPress={() => onSelect(item.key)}
          style={({ pressed }) => [
            styles.quickNavItem,
            active === item.key && (preferences.navStyle === "line" ? styles.quickNavItemLineActive : styles.quickNavItemActive),
            pressed && styles.pressed,
          ]}
        >
          <MaterialCommunityIcons
            name={item.icon}
            size={20}
            color={active === item.key ? palette.rose : palette.muted}
          />
          {preferences.navStyle !== "minimal" && (
            <Text style={[styles.quickNavLabel, active === item.key && styles.quickNavLabelActive]}>
              {item.label}
            </Text>
          )}
        </Pressable>
      ))}
    </View>
  );
}

function LedgerModal({
  mode,
  ledgerName,
  inviteCode,
  ledgerType,
  error,
  busy,
  setLedgerName,
  setInviteCode,
  setLedgerType,
  onClose,
  onSubmit,
}: {
  mode: "create" | "join" | null;
  ledgerName: string;
  inviteCode: string;
  ledgerType: "couple" | "roommate" | "family";
  error: string;
  busy: boolean;
  setLedgerName: (value: string) => void;
  setInviteCode: (value: string) => void;
  setLedgerType: (value: "couple" | "roommate" | "family") => void;
  onClose: () => void;
  onSubmit: () => void;
}) {
  const { palette } = useAppearance();
  return (
    <Modal
      visible={Boolean(mode)}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        style={styles.modalBackdrop}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <Pressable style={styles.modalDismiss} onPress={onClose} />
        <View style={styles.modalCard}>
          <View style={styles.modalHandle} />
          <Text style={styles.modalTitle}>
            {mode === "create" ? "建立空白共同帳本" : "加入共同帳本"}
          </Text>
          <Text style={styles.modalDescription}>
            {mode === "create"
              ? "建立全新空白帳本，不含任何預設交易或收支記錄。"
              : "輸入對方分享給你的邀請碼。"}
          </Text>
          {mode === "create" ? (
            <>
              <View style={styles.segmentRow}>
                {(["couple", "roommate", "family"] as const).map(item => (
                  <Pressable
                    key={item}
                    onPress={() => setLedgerType(item)}
                    style={[styles.segment, ledgerType === item && styles.segmentActive]}
                  >
                    <Text style={[styles.segmentText, ledgerType === item && styles.segmentTextActive]}>
                      {item === "couple" ? "情侶" : item === "roommate" ? "室友" : "家庭"}
                    </Text>
                  </Pressable>
                ))}
              </View>
              <TextInput
              value={ledgerName}
              onChangeText={setLedgerName}
              placeholder="例如：小辰 ＆ 安安"
              placeholderTextColor="#B9A69E"
              style={styles.input}
                autoFocus
              />
            </>
          ) : (
            <TextInput
              value={inviteCode}
              onChangeText={setInviteCode}
              placeholder="輸入邀請碼"
              placeholderTextColor="#B9A69E"
              style={styles.input}
              autoCapitalize="characters"
              autoFocus
            />
          )}
          {!!error && <Text style={styles.errorText}>{error}</Text>}
          <Pressable
            disabled={busy}
            onPress={onSubmit}
            style={({ pressed }) => [
              styles.primaryButton,
              pressed && styles.pressed,
              busy && styles.disabled,
            ]}
          >
            <Text style={styles.primaryButtonText}>
              {busy
                ? "處理中…"
                : mode === "create"
                  ? "建立空白帳本"
                  : "加入帳本"}
            </Text>
            {busy && <ActivityIndicator color="#FFFFFF" />}
          </Pressable>
          <Pressable onPress={onClose} style={styles.modalCancel}>
            <Text style={styles.modalCancelText}>取消</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function LedgerManageModal({
  visible,
  mode,
  ledger,
  members,
  user,
  error,
  busy,
  onClose,
  onRename,
  onTransfer,
}: {
  visible: boolean;
  mode: "rename" | "transfer";
  ledger: Ledger;
  members: LedgerMember[];
  user: User;
  error: string;
  busy: boolean;
  onClose: () => void;
  onRename: (name: string) => void;
  onTransfer: (targetUserId: number) => void;
}) {
  const { palette } = useAppearance();
  const [draftName, setDraftName] = useState(ledger.name);
  useEffect(() => {
    if (visible) setDraftName(ledger.name);
  }, [visible, ledger.name]);
  const others = members.filter(item => item.user.id !== user.id);
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView style={styles.modalBackdrop} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <Pressable style={styles.modalDismiss} onPress={onClose} />
        <View style={styles.modalCard}>
          <View style={styles.modalHandle} />
          <Text style={styles.modalTitle}>{mode === "rename" ? "修改帳本名稱" : "直接轉讓所有權"}</Text>
          <Text style={styles.modalDescription}>
            {mode === "rename" ? "名稱會同步更新到所有成員的帳本列表。" : "轉讓後你仍會留在帳本中，但會成為一般成員。"}
          </Text>
          {mode === "rename" ? (
            <>
              <TextInput
                value={draftName}
                onChangeText={setDraftName}
                placeholder="輸入帳本名稱"
                placeholderTextColor={palette.muted}
                style={styles.input}
                maxLength={128}
                autoFocus
              />
              {!!error && <Text style={styles.errorText}>{error}</Text>}
              <Pressable disabled={busy} onPress={() => onRename(draftName)} style={[styles.primaryButton, busy && styles.disabled]}>
                <Text style={styles.primaryButtonText}>{busy ? "儲存中…" : "儲存名稱"}</Text>
                {busy && <ActivityIndicator color="#FFFFFF" />}
              </Pressable>
            </>
          ) : (
            <View style={styles.modalOptionList}>
              {others.length === 0 ? (
                <Text style={styles.emptyText}>目前沒有其他可接任的成員。</Text>
              ) : others.map(item => (
                <Pressable key={item.user.id} disabled={busy} onPress={() => onTransfer(item.user.id)} style={styles.modalOptionRow}>
                  <View style={styles.avatarSmall}>
                    <Text style={styles.avatarSmallText}>{(item.user.name || "成").slice(0, 1)}</Text>
                  </View>
                  <View style={styles.memberPaymentName}>
                    <Text style={styles.rowTitle}>{item.user.name || item.user.email || `成員 ${item.user.id}`}</Text>
                    <Text style={styles.rowSubtitle}>{item.member.role === "admin" ? "管理員" : item.member.role === "viewer" ? "檢視者" : "一般成員"}</Text>
                  </View>
                  <MaterialCommunityIcons name="chevron-right" size={20} color={palette.muted} />
                </Pressable>
              ))}
            </View>
          )}
          <Pressable onPress={onClose} style={styles.modalCancel}>
            <Text style={styles.modalCancelText}>取消</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function TravelPlanModal({
  visible,
  name,
  budget,
  startDate,
  endDate,
  notes,
  error,
  busy,
  setName,
  setBudget,
  setStartDate,
  setEndDate,
  setNotes,
  onClose,
  onSubmit,
}: {
  visible: boolean;
  name: string;
  budget: string;
  startDate: string;
  endDate: string;
  notes: string;
  error: string;
  busy: boolean;
  setName: (value: string) => void;
  setBudget: (value: string) => void;
  setStartDate: (value: string) => void;
  setEndDate: (value: string) => void;
  setNotes: (value: string) => void;
  onClose: () => void;
  onSubmit: () => void;
}) {
  const { palette } = useAppearance();
  const [datePicker, setDatePicker] = useState<"start" | "end" | null>(null);
  const isDateValue = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value);
  const pickerValue = datePicker === "end"
    ? (isDateValue(endDate) ? new Date(`${endDate}T12:00:00`) : new Date())
    : (isDateValue(startDate) ? new Date(`${startDate}T12:00:00`) : new Date());
  const pickerMinimumDate = datePicker === "end" && isDateValue(startDate)
    ? new Date(`${startDate}T12:00:00`)
    : undefined;
  const handleDateChange = (event: DateTimePickerEvent, value?: Date) => {
    const currentField = datePicker;
    setDatePicker(null);
    if (event.type === "dismissed" || !value || !currentField) return;
    const selected = dateKey(value);
    if (currentField === "start") {
      setStartDate(selected);
      if (isDateValue(endDate) && endDate < selected) setEndDate(selected);
    } else {
      setEndDate(selected);
    }
  };
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView style={styles.modalBackdrop} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <Pressable style={styles.modalDismiss} onPress={onClose} />
        <ScrollView contentContainerStyle={styles.modalCard} keyboardShouldPersistTaps="handled">
          <View style={styles.modalHandle} />
          <Text style={styles.modalTitle}>新增出遊規劃</Text>
          <Text style={styles.modalDescription}>設定旅行、聚會或短期目標預算，不會納入每月預算。</Text>
          <TextInput value={name} onChangeText={setName} placeholder="例如：台南三日遊" placeholderTextColor={palette.muted} style={styles.input} />
          <TextInput value={budget} onChangeText={setBudget} placeholder="預算金額" placeholderTextColor={palette.muted} keyboardType="number-pad" style={styles.input} />
          <Pressable onPress={() => setDatePicker("start")} style={[styles.datePickerTrigger, { marginBottom: 12 }]} accessibilityRole="button" accessibilityLabel="選擇開始日期">
            <View style={styles.datePickerValueRow}>
              <MaterialCommunityIcons name="calendar-month-outline" size={19} color={palette.rose} />
              <Text style={[styles.datePickerText, !startDate && { color: palette.muted }]}>{startDate || "選擇開始日期"}</Text>
            </View>
            <MaterialCommunityIcons name="chevron-down" size={19} color={palette.muted} />
          </Pressable>
          <Pressable onPress={() => setDatePicker("end")} style={[styles.datePickerTrigger, { marginBottom: 12 }]} accessibilityRole="button" accessibilityLabel="選擇結束日期">
            <View style={styles.datePickerValueRow}>
              <MaterialCommunityIcons name="calendar-check-outline" size={19} color={palette.rose} />
              <Text style={[styles.datePickerText, !endDate && { color: palette.muted }]}>{endDate || "選擇結束日期"}</Text>
            </View>
            <MaterialCommunityIcons name="chevron-down" size={19} color={palette.muted} />
          </Pressable>
          {datePicker && (
            <DateTimePicker
              value={pickerValue}
              mode="date"
              display={Platform.OS === "android" ? "calendar" : "spinner"}
              minimumDate={pickerMinimumDate}
              onChange={handleDateChange}
              accentColor={palette.rose}
            />
          )}
          <TextInput value={notes} onChangeText={setNotes} placeholder="備註（選填）" placeholderTextColor={palette.muted} style={[styles.input, styles.multilineInput]} multiline maxLength={1000} />
          {!!error && <Text style={styles.errorText}>{error}</Text>}
          <Pressable disabled={busy} onPress={onSubmit} style={[styles.primaryButton, busy && styles.disabled]}>
            <Text style={styles.primaryButtonText}>{busy ? "建立中…" : "建立出遊規劃"}</Text>
            {busy && <ActivityIndicator color="#FFFFFF" />}
          </Pressable>
          <Pressable onPress={onClose} style={styles.modalCancel}>
            <Text style={styles.modalCancelText}>取消</Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function ConfirmModal({
  request,
  onClose,
}: {
  request: ConfirmRequest | null;
  onClose: () => void;
}) {
  const { palette } = useAppearance();
  if (!request) return null;
  const run = (callback: () => void | Promise<void>) => {
    onClose();
    void callback();
  };
  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.confirmOverlay}>
        <Pressable style={styles.confirmDismiss} onPress={onClose} />
        <View style={[styles.confirmCard, { backgroundColor: palette.surface, borderColor: palette.border }]}>
          <View style={[styles.confirmIcon, { backgroundColor: request.destructive ? palette.roseSoft : palette.roseSoft }]}>
            <MaterialCommunityIcons
              name={request.destructive ? "alert-outline" : "help-circle-outline"}
              size={24}
              color={palette.rose}
            />
          </View>
          <Text style={styles.confirmTitle}>{request.title}</Text>
          <Text style={styles.confirmMessage}>{request.message}</Text>
          {request.options?.length ? (
            <View style={styles.confirmOptionList}>
              {request.options.map((option, index) => (
                <Pressable
                  key={`${option.label}-${index}`}
                  onPress={() => run(option.onPress)}
                  style={({ pressed }) => [
                    styles.confirmOption,
                    { borderColor: option.destructive ? palette.rose : palette.border },
                    pressed && styles.pressed,
                  ]}
                >
                  <MaterialCommunityIcons
                    name={(option.icon || (option.destructive ? "delete-outline" : "account-switch-outline")) as never}
                    size={19}
                    color={option.destructive ? palette.rose : palette.ink}
                  />
                  <Text style={[styles.confirmOptionText, { color: option.destructive ? palette.rose : palette.ink }]}>
                    {option.label}
                  </Text>
                  <MaterialCommunityIcons name="chevron-right" size={19} color={palette.muted} />
                </Pressable>
              ))}
            </View>
          ) : (
            <View style={styles.confirmActions}>
              <Pressable onPress={onClose} style={[styles.confirmCancel, { borderColor: palette.border }]}>
                <Text style={[styles.confirmCancelText, { color: palette.muted }]}>{request.cancelText || "取消"}</Text>
              </Pressable>
              <Pressable
                onPress={() => run(request.onConfirm || (() => undefined))}
                style={({ pressed }) => [
                  styles.confirmPrimary,
                  { backgroundColor: request.destructive ? palette.rose : palette.burgundy },
                  pressed && styles.pressed,
                ]}
              >
                <Text style={styles.confirmPrimaryText}>{request.confirmText || "確定"}</Text>
              </Pressable>
            </View>
          )}
          {!!request.options?.length && (
            <Pressable onPress={onClose} style={styles.confirmCancelLink}>
              <Text style={[styles.confirmCancelText, { color: palette.muted }]}>{request.cancelText || "取消"}</Text>
            </Pressable>
          )}
        </View>
      </View>
    </Modal>
  );
}

function TransactionModal({
  visible,
  editingTransaction,
  user,
  members,
  categories,
  paymentMethods,
  error,
  onClose,
  onSetupPayment,
  onSubmit,
}: {
  visible: boolean;
  editingTransaction: Transaction | null;
  user: User;
  members: LedgerMember[];
  categories: Category[];
  paymentMethods: PaymentMethod[];
  error: string;
  onClose: () => void;
  onSetupPayment: () => void;
  onSubmit: (input: {
    payerId: number;
    amount: number;
    type: "expense" | "income";
    categoryId: number;
    paymentMethodId: number;
    date: Date;
    note?: string;
    splitType: "equal" | "custom" | "amount" | "none";
    splits: { userId: number; shareAmount: number }[];
  }) => void;
}) {
  const { palette } = useAppearance();
  const [amountText, setAmountText] = useState("");
  const [type, setType] = useState<"expense" | "income">("expense");
  const [categoryId, setCategoryId] = useState("");
  const [paymentId, setPaymentId] = useState("");
  const [payerId, setPayerId] = useState(String(user.id));
  const [dateText, setDateText] = useState(dateKey(new Date()));
  const [note, setNote] = useState("");
  const [splitType, setSplitType] = useState<"equal" | "custom" | "amount" | "none">(
    "equal"
  );
  const [splitValues, setSplitValues] = useState<Record<number, string>>({});
  const [categorySearch, setCategorySearch] = useState("");
  const [datePickerVisible, setDatePickerVisible] = useState(false);
  const [calendarMonth, setCalendarMonth] = useState(() => currentMonth());
  const [scanning, setScanning] = useState(false);
  const [localError, setLocalError] = useState("");
  useEffect(() => {
    if (visible) {
      const tx = editingTransaction;
      setAmountText(tx ? String(tx.amount) : "");
      setType(tx?.type === "income" ? "income" : "expense");
      setCategoryId(tx ? String(tx.categoryId) : "");
      setPaymentId(tx ? String(tx.paymentMethodId) : "");
      setPayerId(tx ? String(tx.payerId) : String(user.id));
      const initialDate = tx ? dateKey(tx.date) : dateKey(new Date());
      setDateText(initialDate);
      setCalendarMonth(initialDate.slice(0, 7));
      setNote(tx?.note || "");
      setSplitType(tx?.splitType || "equal");
      setSplitValues({});
      setCategorySearch("");
      setDatePickerVisible(false);
      setLocalError("");
    }
  }, [visible, user.id, editingTransaction?.id]);
  const availableCategories = categories.filter(item => item.type === type && item.isActive !== 0);
  const filteredCategories = availableCategories.filter(item =>
    `${item.name} ${item.icon}`.toLowerCase().includes(categorySearch.trim().toLowerCase())
  );
  const activePaymentMethods = paymentMethods.filter(item => item.isActive !== 0);
  const selectedCategories = categoryId || String(availableCategories[0]?.id || "");
  const selectedPayment = paymentId || String(activePaymentMethods[0]?.id || "");
  const scanReceiptAsset = async (asset: ImagePicker.ImagePickerAsset | undefined) => {
    if (!asset?.base64) {
      setLocalError("無法讀取發票影像，請重新拍攝或選圖。");
      return;
    }
    setScanning(true);
    setLocalError("");
    try {
      const imageDataUrl = `data:${asset.mimeType || "image/jpeg"};base64,${asset.base64}`;
      const result = await api.ledger.scanReceipt.mutate({ imageDataUrl });
      if (result.amount) setAmountText(String(result.amount));
      if (result.date && /^\d{4}-\d{2}-\d{2}$/.test(result.date)) {
        setDateText(result.date);
        setCalendarMonth(result.date.slice(0, 7));
      }
      if (result.note) setNote(result.note);
      if (!result.amount && !result.date && !result.note) setLocalError("發票資訊不清楚，請手動確認欄位。");
    } catch (scanError) {
      setLocalError(scanError instanceof Error ? scanError.message : "發票辨識失敗，請改用手動輸入。");
    } finally {
      setScanning(false);
    }
  };
  const pickReceipt = async (source: "camera" | "library") => {
    try {
      const result = source === "camera"
        ? await ImagePicker.launchCameraAsync({ base64: true, quality: 0.68, allowsEditing: false, exif: false })
        : await ImagePicker.launchImageLibraryAsync({ base64: true, quality: 0.68, allowsEditing: false, mediaTypes: ["images"], selectionLimit: 1 });
      if (!result.canceled) await scanReceiptAsset(result.assets[0]);
    } catch (pickerError) {
      setLocalError(pickerError instanceof Error ? pickerError.message : "無法開啟影像選取功能。");
    }
  };
  const [calendarYear, calendarMonthNumber] = calendarMonth.split("-").map(Number);
  const calendarFirstDay = new Date(calendarYear, calendarMonthNumber - 1, 1).getDay();
  const calendarDays = new Date(calendarYear, calendarMonthNumber, 0).getDate();
  const calendarCells = Array.from({ length: calendarFirstDay + calendarDays }, (_, index) =>
    index < calendarFirstDay ? null : index - calendarFirstDay + 1
  );
  const submit = () => {
    const amount = Number(amountText);
    if (!Number.isInteger(amount) || amount <= 0) {
      setLocalError("請輸入正整數金額。");
      return;
    }
    if (!selectedCategories || !selectedPayment) {
      setLocalError("請先到設定建立分類與支付方式。");
      return;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateText)) {
      setLocalError("日期格式請使用 YYYY-MM-DD。");
      return;
    }
    let splits: { userId: number; shareAmount: number }[] = [];
    if (type === "expense") {
      if (splitType === "equal") {
        const share = Math.floor(amount / Math.max(1, members.length));
        const remainder = amount - share * Math.max(1, members.length);
        splits = members.map((member, index) => ({
          userId: member.user.id,
          shareAmount: share + (index === 0 ? remainder : 0),
        }));
      } else if (splitType === "custom") {
        const ratios = members.map(member => ({
          userId: member.user.id,
          ratio: Number(splitValues[member.user.id] || 0),
        }));
        if (
          ratios.some(item => !Number.isFinite(item.ratio) || item.ratio < 0) ||
          Math.round(ratios.reduce((sum, item) => sum + item.ratio, 0) * 100) / 100 !== 100
        ) {
          setLocalError("自訂比例總和必須剛好是 100%。");
          return;
        }
        const rawShares = ratios.map(item => ({
          userId: item.userId,
          shareAmount: Math.floor((amount * item.ratio) / 100),
        }));
        const remainder = amount - rawShares.reduce((sum, item) => sum + item.shareAmount, 0);
        splits = rawShares.map((item, index) => ({
          userId: item.userId,
          shareAmount: item.shareAmount + (index === 0 ? remainder : 0),
        }));
      } else if (splitType === "amount") {
        splits = members
          .map(member => ({
            userId: member.user.id,
            shareAmount: Number(splitValues[member.user.id] || 0),
          }))
          .filter(item => item.shareAmount > 0);
        if (splits.reduce((sum, item) => sum + item.shareAmount, 0) !== amount) {
          setLocalError("直接分攤金額必須剛好等於總金額。");
          return;
        }
      }
    }
    onSubmit({
      payerId: Number(payerId),
      amount,
      type,
      categoryId: Number(selectedCategories),
      paymentMethodId: Number(selectedPayment),
      date: new Date(`${dateText}T12:00:00`),
      note: note.trim() || undefined,
      splitType,
      splits,
    });
  };
  const changeCalendarMonth = (offset: number) => {
    const next = new Date(calendarYear, calendarMonthNumber - 1 + offset, 1);
    setCalendarMonth(`${next.getFullYear()}-${String(next.getMonth() + 1).padStart(2, "0")}`);
  };
  return (
    <>
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        style={styles.modalBackdrop}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <Pressable style={styles.modalDismiss} onPress={onClose} />
        <ScrollView style={styles.modalScroll}>
          <View style={styles.modalCard}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>{editingTransaction ? "編輯收支記錄" : "新增收支記錄"}</Text>
            <Text style={styles.modalDescription}>
              金額、分類、日期、付款人、支付方式、備註與分攤方式都會保存。
            </Text>
            <View style={styles.receiptActions}>
              <Pressable disabled={scanning} onPress={() => pickReceipt("camera")} style={styles.receiptButton}>
                <MaterialCommunityIcons name="camera-outline" size={17} color={palette.rose} />
                <Text style={styles.receiptButtonText}>{scanning ? "辨識中…" : "拍照掃描發票"}</Text>
              </Pressable>
              <Pressable disabled={scanning} onPress={() => pickReceipt("library")} style={styles.receiptButton}>
                <MaterialCommunityIcons name="image-multiple-outline" size={17} color={palette.rose} />
                <Text style={styles.receiptButtonText}>從相簿選圖</Text>
              </Pressable>
            </View>
            {paymentMethods.length === 0 && (
              <View style={styles.setupNotice}>
                <MaterialCommunityIcons
                  name="credit-card-outline"
                  size={19}
                  color={palette.rose}
                />
                <View style={styles.setupNoticeCopy}>
                  <Text style={styles.setupNoticeTitle}>尚未建立支付方式</Text>
                  <Text style={styles.setupNoticeBody}>
                    先新增現金、信用卡或其他方式，才能儲存收支。
                  </Text>
                </View>
                <Pressable onPress={onSetupPayment} style={styles.setupNoticeButton}>
                  <Text style={styles.setupNoticeButtonText}>去設定</Text>
                </Pressable>
              </View>
            )}
            <View style={styles.segmentRow}>
              {(["expense", "income"] as const).map(item => (
                <Pressable
                  key={item}
                  onPress={() => {
                    setType(item);
                    setCategoryId("");
                  }}
                  style={[
                    styles.segment,
                    type === item && styles.segmentActive,
                  ]}
                >
                  <Text
                    style={[
                      styles.segmentText,
                      type === item && styles.segmentTextActive,
                    ]}
                  >
                    {item === "expense" ? "支出" : "收入"}
                  </Text>
                </Pressable>
              ))}
            </View>
            <Field label="金額">
              <TextInput
                value={amountText}
                onChangeText={setAmountText}
                placeholder="例如 680"
                keyboardType="numeric"
                placeholderTextColor="#B9A69E"
                style={styles.input}
              />
            </Field>
            <Field label="分類">
              <TextInput
                value={categorySearch}
                onChangeText={setCategorySearch}
                placeholder="搜尋分類名稱"
                placeholderTextColor="#B9A69E"
                style={styles.input}
              />
              <OptionScroller
                items={filteredCategories.map(item => ({ id: item.id, label: `${item.icon} ${item.name}` }))}
                value={Number(selectedCategories)}
                onChange={value => setCategoryId(String(value))}
              />
            </Field>
            <Field label="付款人">
              <OptionScroller
                items={members.map(item => ({
                  id: item.user.id,
                  label:
                    item.user.id === user.id
                      ? "你"
                      : item.user.name || item.user.email || "成員",
                }))}
                value={Number(payerId)}
                onChange={value => setPayerId(String(value))}
              />
            </Field>
            <Field label="支付方式">
              <OptionScroller
                items={activePaymentMethods.map(item => ({ id: item.id, label: `${item.icon} ${item.name}` }))}
                value={Number(selectedPayment)}
                onChange={value => setPaymentId(String(value))}
              />
            </Field>
            <Field label="日期">
              <Pressable onPress={() => setDatePickerVisible(true)} style={styles.datePickerTrigger}>
                <Text style={styles.datePickerText}>{dateText}</Text>
                <MaterialCommunityIcons name="calendar-month-outline" size={19} color={palette.rose} />
              </Pressable>
            </Field>
            <Field label="分攤方式">
              {type === "income" ? (
                <Text style={styles.rowSubtitle}>收入不需要分攤。</Text>
              ) : (
                <>
                  <View style={styles.segmentRow}>
                    {(["equal", "custom", "amount", "none"] as const).map(item => (
                      <Pressable
                        key={item}
                        onPress={() => setSplitType(item)}
                        style={[
                          styles.miniSegment,
                          splitType === item && styles.miniSegmentActive,
                        ]}
                      >
                        <Text
                          style={[
                            styles.miniSegmentText,
                            splitType === item && styles.miniSegmentTextActive,
                          ]}
                        >
                          {item === "equal"
                            ? "平均"
                            : item === "custom"
                              ? "自訂比例"
                              : item === "amount" ? "直接金額" : "無分攤"}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                  {splitType !== "equal" && splitType !== "none" &&
                    members.map(member => (
                      <View key={member.user.id} style={styles.splitInputRow}>
                        <Text style={styles.rowTitle}>
                          {member.user.name || member.user.email || "成員"}
                        </Text>
                        <TextInput
                          value={splitValues[member.user.id] || ""}
                          onChangeText={value =>
                            setSplitValues(previous => ({
                              ...previous,
                              [member.user.id]: value,
                            }))
                          }
                          keyboardType="numeric"
                          placeholder={splitType === "custom" ? "比例 %" : "分攤金額"}
                          placeholderTextColor="#B9A69E"
                          style={styles.splitInput}
                        />
                      </View>
                    ))}
                </>
              )}
            </Field>
            <Field label="備註">
              <TextInput
                value={note}
                onChangeText={setNote}
                placeholder="例如：週末晚餐"
                placeholderTextColor="#B9A69E"
                style={[styles.input, styles.textarea]}
                multiline
              />
            </Field>
            {!!localError && <Text style={styles.errorText}>{localError}</Text>}
            {!!error && <Text style={styles.errorText}>{error}</Text>}
            <Pressable
              onPress={submit}
              style={({ pressed }) => [
                styles.primaryButton,
                pressed && styles.pressed,
              ]}
            >
              <Text style={styles.primaryButtonText}>儲存這筆記錄</Text>
            </Pressable>
            <Pressable onPress={onClose} style={styles.modalCancel}>
              <Text style={styles.modalCancelText}>取消</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
    <Modal visible={datePickerVisible} transparent animationType="fade" onRequestClose={() => setDatePickerVisible(false)}>
      <View style={styles.calendarOverlay}>
        <View style={styles.dateCalendarCard}>
          <View style={styles.calendarHeader}>
            <Pressable onPress={() => changeCalendarMonth(-1)} style={styles.calendarArrow}><MaterialCommunityIcons name="chevron-left" size={22} color={palette.ink} /></Pressable>
            <Text style={styles.calendarMonthTitle}>{calendarMonth.replace("-", " / ")}</Text>
            <Pressable onPress={() => changeCalendarMonth(1)} style={styles.calendarArrow}><MaterialCommunityIcons name="chevron-right" size={22} color={palette.ink} /></Pressable>
          </View>
          <View style={styles.calendarWeekRow}>{["日", "一", "二", "三", "四", "五", "六"].map(day => <Text key={day} style={styles.calendarWeekday}>{day}</Text>)}</View>
          <View style={styles.calendarGrid}>
            {calendarCells.map((day, index) => day ? (
              <Pressable key={`${calendarMonth}-${day}`} onPress={() => { const chosen = `${calendarMonth}-${String(day).padStart(2, "0")}`; setDateText(chosen); setDatePickerVisible(false); }} style={[styles.calendarDayCell, dateText === `${calendarMonth}-${String(day).padStart(2, "0")}` && styles.calendarDayActive]}>
                <Text style={[styles.calendarDayText, dateText === `${calendarMonth}-${String(day).padStart(2, "0")}` && styles.calendarDayTextActive]}>{day}</Text>
              </Pressable>
            ) : <View key={`empty-${index}`} style={styles.calendarDayCell} />)}
          </View>
          <Pressable onPress={() => setDatePickerVisible(false)} style={styles.modalCancel}><Text style={styles.modalCancelText}>關閉</Text></Pressable>
        </View>
      </View>
    </Modal>
    </>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <View style={styles.field}>
      <Text style={styles.fieldLabel}>{label}</Text>
      {children}
    </View>
  );
}
function OptionScroller({
  items,
  value,
  onChange,
}: {
  items: { id: number; label: string }[];
  value: number;
  onChange: (value: number) => void;
}) {
  const { palette } = useAppearance();
  return items.length === 0 ? (
    <Text style={styles.rowSubtitle}>尚未建立選項，請先到設定新增。</Text>
  ) : (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.optionScroller}
    >
      {items.map(item => (
        <Pressable
          key={item.id}
          onPress={() => onChange(item.id)}
          style={[
            styles.optionChip,
            value === item.id && styles.optionChipActive,
          ]}
        >
          <Text
            style={[
              styles.optionChipText,
              value === item.id && styles.optionChipTextActive,
            ]}
          >
            {item.label}
          </Text>
        </Pressable>
      ))}
    </ScrollView>
  );
}

const MAX_BUDGET_AMOUNT = 100_000_000;

function BudgetModal({
  visible,
  categories,
  currentMonth: month,
  ledgerId,
  onClose,
  onSubmit,
}: {
  visible: boolean;
  categories: Category[];
  currentMonth: string;
  ledgerId: number;
  onClose: () => void;
  onSubmit: (input: {
    ledgerId: number;
    categoryId: number;
    amount: number;
    month: string;
  }) => void;
}) {
  const { palette } = useAppearance();
  const [categoryId, setCategoryId] = useState<number>(0);
  const [amount, setAmount] = useState("");
  const [localError, setLocalError] = useState("");
  useEffect(() => {
    if (visible) {
      setCategoryId(0);
      setAmount("");
      setLocalError("");
    }
  }, [visible]);
  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        style={styles.modalBackdrop}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <Pressable style={styles.modalDismiss} onPress={onClose} />
        <View style={styles.modalCard}>
          <View style={styles.modalHandle} />
          <Text style={styles.modalTitle}>設定預算</Text>
          <Text style={styles.modalDescription}>
            設定本月總預算或指定分類預算；超支時會顯示警示。
          </Text>
          <OptionScroller
            items={[
              { id: 0, label: "總預算" },
              ...categories
                .filter(item => item.type === "expense")
                .map(item => ({
                  id: item.id,
                  label: `${item.icon} ${item.name}`,
                })),
            ]}
            value={categoryId}
            onChange={value => setCategoryId(value)}
          />
          <TextInput
            value={amount}
            onChangeText={setAmount}
            keyboardType="numeric"
            placeholder="預算金額（最高 NT$ 100,000,000）"
            placeholderTextColor={palette.muted}
            maxLength={9}
            style={styles.input}
          />
          {!!localError && <Text style={styles.errorText}>{localError}</Text>}
          <Pressable
            onPress={() => {
              const value = Number(amount);
              if (!Number.isInteger(value) || value <= 0) {
                setLocalError("請輸入正整數預算。");
                return;
              }
              if (value > MAX_BUDGET_AMOUNT) {
                setLocalError("預算上限為 NT$ 100,000,000，請分開規劃較大的目標。");
                return;
              }
              onSubmit({
                ledgerId,
                categoryId: Number(categoryId) || 0,
                amount: value,
                month,
              });
            }}
            style={({ pressed }) => [
              styles.primaryButton,
              pressed && styles.pressed,
            ]}
          >
            <Text style={styles.primaryButtonText}>儲存預算</Text>
          </Pressable>
          <Pressable onPress={onClose} style={styles.modalCancel}>
            <Text style={styles.modalCancelText}>取消</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function RecurringModal({
  visible,
  categories,
  paymentMethods,
  ledgerId,
  onClose,
  onSubmit,
}: {
  visible: boolean;
  categories: Category[];
  paymentMethods: PaymentMethod[];
  ledgerId: number;
  onClose: () => void;
  onSubmit: (input: {
    title: string;
    amount: number;
    type: "expense" | "income";
    categoryId: number;
    paymentMethodId: number;
    frequency: "weekly" | "monthly" | "yearly";
    dayOfMonth: number;
  }) => void;
}) {
  const { palette } = useAppearance();
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [type, setType] = useState<"expense" | "income">("expense");
  const [categoryId, setCategoryId] = useState("");
  const [paymentId, setPaymentId] = useState("");
  const [frequency, setFrequency] = useState<"weekly" | "monthly" | "yearly">(
    "monthly"
  );
  const [day, setDay] = useState("1");
  const [localError, setLocalError] = useState("");
  useEffect(() => {
    if (visible) {
      setTitle("");
      setAmount("");
      setType("expense");
      setCategoryId("");
      setPaymentId("");
      setFrequency("monthly");
      setDay("1");
      setLocalError("");
    }
  }, [visible]);
  const filtered = categories.filter(item => item.type === type);
  const selectedCategory = categoryId || String(filtered[0]?.id || "");
  const selectedPayment = paymentId || String(paymentMethods[0]?.id || "");
  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        style={styles.modalBackdrop}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <Pressable style={styles.modalDismiss} onPress={onClose} />
        <ScrollView style={styles.modalScroll}>
          <View style={styles.modalCard}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>新增固定收支</Text>
            <Text style={styles.modalDescription}>
              每次開啟帳本時會以固定鍵檢查並補入當期記錄，不會重複建立。
            </Text>
            <TextInput
              value={title}
              onChangeText={setTitle}
              placeholder="項目名稱，例如房租／薪資"
              placeholderTextColor="#B9A69E"
              style={styles.input}
            />
            <View style={styles.segmentRow}>
              {(["expense", "income"] as const).map(item => (
                <Pressable
                  key={item}
                  onPress={() => {
                    setType(item);
                    setCategoryId("");
                  }}
                  style={[
                    styles.segment,
                    type === item && styles.segmentActive,
                  ]}
                >
                  <Text
                    style={[
                      styles.segmentText,
                      type === item && styles.segmentTextActive,
                    ]}
                  >
                    {item === "expense" ? "固定支出" : "固定收入"}
                  </Text>
                </Pressable>
              ))}
            </View>
            <TextInput
              value={amount}
              onChangeText={setAmount}
              keyboardType="numeric"
              placeholder="金額"
              placeholderTextColor="#B9A69E"
              style={styles.input}
            />
            <Field label="分類">
              <OptionScroller
                items={filtered.map(item => ({
                  id: item.id,
                  label: `${item.icon} ${item.name}`,
                }))}
                value={Number(selectedCategory)}
                onChange={value => setCategoryId(String(value))}
              />
            </Field>
            <Field label="支付方式">
              <OptionScroller
                items={paymentMethods.map(item => ({
                  id: item.id,
                  label: `${item.icon} ${item.name}`,
                }))}
                value={Number(selectedPayment)}
                onChange={value => setPaymentId(String(value))}
              />
            </Field>
            <Field label="頻率">
              <View style={styles.segmentRow}>
                {(["weekly", "monthly", "yearly"] as const).map(item => (
                  <Pressable
                    key={item}
                    onPress={() => setFrequency(item)}
                    style={[
                      styles.miniSegment,
                      frequency === item && styles.miniSegmentActive,
                    ]}
                  >
                    <Text
                      style={[
                        styles.miniSegmentText,
                        frequency === item && styles.miniSegmentTextActive,
                      ]}
                    >
                      {item === "weekly"
                        ? "每週"
                        : item === "monthly"
                          ? "每月"
                          : "每年"}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </Field>
            <TextInput
              value={day}
              onChangeText={setDay}
              keyboardType="numeric"
              placeholder="每月幾號（1-31）"
              placeholderTextColor="#B9A69E"
              style={styles.input}
            />
            {!!localError && <Text style={styles.errorText}>{localError}</Text>}
            <Pressable
              onPress={() => {
                const parsedAmount = Number(amount);
                const parsedDay = Number(day);
                if (
                  !title.trim() ||
                  !Number.isInteger(parsedAmount) ||
                  parsedAmount <= 0 ||
                  !selectedCategory ||
                  !selectedPayment ||
                  parsedDay < 1 ||
                  parsedDay > 31
                ) {
                  setLocalError("請完整填寫名稱、金額、分類、支付方式與日期。");
                  return;
                }
                onSubmit({
                  title: title.trim(),
                  amount: parsedAmount,
                  type,
                  categoryId: Number(selectedCategory),
                  paymentMethodId: Number(selectedPayment),
                  frequency,
                  dayOfMonth: parsedDay,
                });
              }}
              style={({ pressed }) => [
                styles.primaryButton,
                pressed && styles.pressed,
              ]}
            >
              <Text style={styles.primaryButtonText}>儲存固定收支</Text>
            </Pressable>
            <Pressable onPress={onClose} style={styles.modalCancel}>
              <Text style={styles.modalCancelText}>取消</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function SettingsModal({
  visible,
  mode,
  ledgerId,
  categories,
  onClose,
  onSubmit,
}: {
  visible: boolean;
  mode: "category" | "payment";
  ledgerId: number;
  categories: Category[];
  onClose: () => void;
  onSubmit: (input: {
    parentCategoryId: number;
    name: string;
    type: "expense" | "income";
    icon: string;
  }) => void;
}) {
  const { palette } = useAppearance();
  const [name, setName] = useState("");
  const [type, setType] = useState<"expense" | "income">("expense");
  const [parent, setParent] = useState("0");
  const [icon, setIcon] = useState(mode === "category" ? "◌" : "💳");
  const [localError, setLocalError] = useState("");
  useEffect(() => {
    if (visible) {
      setName("");
      setType("expense");
      setParent("0");
      setIcon(mode === "category" ? "◌" : "💳");
      setLocalError("");
    }
  }, [visible, mode]);
  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        style={styles.modalBackdrop}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <Pressable style={styles.modalDismiss} onPress={onClose} />
        <View style={styles.modalCard}>
          <View style={styles.modalHandle} />
          <Text style={styles.modalTitle}>
            {mode === "category" ? "新增分類／子分類" : "新增支付方式"}
          </Text>
          <Text style={styles.modalDescription}>
            {mode === "category"
              ? "可建立飲食、交通等主分類，也可選擇父分類建立子分類。"
              : "建立你的現金、信用卡或其他支付方式。"}
          </Text>
          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="名稱"
            placeholderTextColor="#B9A69E"
            style={styles.input}
          />
          <TextInput
            value={icon}
            onChangeText={setIcon}
            placeholder="圖示"
            placeholderTextColor="#B9A69E"
            style={styles.input}
          />
          {mode === "category" && (
            <>
              <View style={styles.segmentRow}>
                {(["expense", "income"] as const).map(item => (
                  <Pressable
                    key={item}
                    onPress={() => setType(item)}
                    style={[
                      styles.segment,
                      type === item && styles.segmentActive,
                    ]}
                  >
                    <Text
                      style={[
                        styles.segmentText,
                        type === item && styles.segmentTextActive,
                      ]}
                    >
                      {item === "expense" ? "支出分類" : "收入分類"}
                    </Text>
                  </Pressable>
                ))}
              </View>
              <OptionScroller
                items={[
                  { id: 0, label: "主分類" },
                  ...categories
                    .filter(item => item.type === type)
                    .map(item => ({
                      id: item.id,
                      label: `${item.icon} ${item.name}`,
                    })),
                ]}
                value={Number(parent)}
                onChange={value => setParent(String(value))}
              />
            </>
          )}
          {!!localError && <Text style={styles.errorText}>{localError}</Text>}
          <Pressable
            onPress={() => {
              if (!name.trim()) {
                setLocalError("請輸入名稱。");
                return;
              }
              onSubmit({
                parentCategoryId: Number(parent),
                name: name.trim(),
                type,
                icon: icon.trim() || (mode === "category" ? "◌" : "💳"),
              });
            }}
            style={({ pressed }) => [
              styles.primaryButton,
              pressed && styles.pressed,
            ]}
          >
            <Text style={styles.primaryButtonText}>儲存</Text>
          </Pressable>
          <Pressable onPress={onClose} style={styles.modalCancel}>
            <Text style={styles.modalCancelText}>取消</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const createStyles = (palette: typeof colors, preferences: AppearancePreferences = appearanceDefaults) => {
  const cardRadius = preferences.cardStyle === "outlined" ? 12 : preferences.cardStyle === "flat" ? 4 : 22;
  const cardBorderWidth = preferences.cardStyle === "outlined" ? 2 : preferences.cardStyle === "flat" ? 0 : 1;
  return StyleSheet.create({
  flex: { flex: 1 },
  screen: { flex: 1, backgroundColor: palette.background },
  loadingScreen: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: palette.background,
  },
  loadingText: { marginTop: 12, color: palette.muted, fontSize: 13 },
  loginContent: {
    flexGrow: 1,
    paddingHorizontal: 28,
    paddingTop: 42,
    paddingBottom: 30,
  },
  brandMark: {
    width: 56,
    height: 56,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    backgroundColor: palette.roseSoft,
  },
  brandTitle: {
    marginTop: 13,
    color: palette.ink,
    fontSize: 26,
    fontWeight: "700",
    letterSpacing: 1,
  },
  brandSubtitle: {
    marginTop: 2,
    color: "#B69E94",
    fontSize: 9,
    letterSpacing: 2.4,
  },
  loginHeading: {
    marginTop: 52,
    color: palette.ink,
    fontSize: 31,
    fontWeight: "700",
    lineHeight: 42,
  },
  loginDescription: {
    marginTop: 14,
    color: palette.muted,
    fontSize: 15,
    lineHeight: 23,
  },
  formCard: {
    marginTop: 34,
    padding: 20,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 22,
    backgroundColor: palette.surface,
  },
  formTitle: { color: palette.ink, fontSize: 18, fontWeight: "700" },
  formBody: { marginTop: 8, color: palette.muted, fontSize: 13, lineHeight: 21 },
  privacyText: {
    marginTop: 22,
    color: "#AE9C94",
    fontSize: 12,
    lineHeight: 19,
    textAlign: "center",
  },
  pageContent: {
    padding: 18,
    paddingBottom: 60,
  },
  ledgerSelector: {
    marginBottom: 14,
  },
  selectorLabel: {
    color: palette.muted,
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 0.5,
    marginBottom: 7,
    textTransform: "uppercase",
  },
  ledgerChip: {
    minHeight: 36,
    maxWidth: 190,
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    paddingHorizontal: 13,
    marginRight: 8,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: palette.border,
    backgroundColor: palette.surface,
  },
  ledgerChipActive: {
    borderColor: palette.roseSoft,
    backgroundColor: palette.roseSoft,
  },
  ledgerChipText: {
    color: palette.muted,
    fontSize: 12,
    fontWeight: "600",
  },
  ledgerChipTextActive: {
    color: palette.rose,
    fontWeight: "800",
  },
  sectionIntro: { marginBottom: 20 },
  eyebrow: {
    color: palette.rose,
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1.6,
  },
  sectionTitle: {
    marginTop: 7,
    color: palette.ink,
    fontSize: 27,
    fontWeight: "700",
  },
  sectionBody: {
    marginTop: 8,
    color: palette.muted,
    fontSize: 13,
    lineHeight: 20,
  },
  globalError: {
    marginBottom: 14,
    padding: 12,
    borderRadius: 12,
    color: "#B4575D",
    backgroundColor: "#FBE9E7",
    fontSize: 12,
  },
  headerSafe: { backgroundColor: palette.surface },
  headerActions: { flexDirection: "row", alignItems: "center", gap: 8 },
  appHeader: {
    minHeight: 74,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: palette.border,
  },
  menuButton: {
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
  },
  headerTitleWrap: { flex: 1, marginLeft: 8 },
  headerTitle: { color: palette.ink, fontSize: 21, fontWeight: "700" },
  headerCaption: { marginTop: 2, color: palette.muted, fontSize: 11 },
  headerAddButton: {
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
    backgroundColor: palette.rose,
  },
  headerSpacer: { width: 44 },
  headerBackButton: {
    width: 42,
    height: 42,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
    backgroundColor: "#F5EFEC",
  },
  quickNav: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    paddingHorizontal: 8,
    paddingTop: 8,
    paddingBottom: 8,
    borderTopWidth: 1,
    borderTopColor: palette.border,
    backgroundColor: palette.surface,
  },
  quickNavPill: {
    marginHorizontal: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 24,
    shadowColor: palette.ink,
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
    elevation: 3,
  },
  quickNavLine: {
    paddingTop: 0,
    paddingBottom: 0,
    borderTopWidth: 0,
    borderBottomWidth: 1,
    borderBottomColor: palette.border,
    backgroundColor: "transparent",
  },
  quickNavMinimal: {
    minHeight: 48,
    paddingTop: 2,
    paddingBottom: 2,
    borderTopWidth: 0,
    backgroundColor: "transparent",
  },
  quickNavItem: {
    minWidth: 58,
    alignItems: "center",
    justifyContent: "center",
    gap: 3,
    paddingVertical: 4,
    borderRadius: 13,
  },
  quickNavItemActive: { backgroundColor: palette.roseSoft },
  quickNavItemLineActive: { backgroundColor: "transparent", borderTopWidth: 2, borderTopColor: palette.rose, borderRadius: 0, paddingTop: 6 },
  quickNavLabel: { color: palette.muted, fontSize: 10, fontWeight: "600" },
  quickNavLabelActive: { color: palette.rose, fontWeight: "800" },
  ledgerHomeContent: { flexGrow: 1, padding: 18, paddingBottom: 40 },
  profileContent: { flexGrow: 1, padding: 18, paddingBottom: 42 },
  ledgerHomeCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 19,
    backgroundColor: palette.surface,
  },
  ledgerHomeIcon: {
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 15,
    backgroundColor: palette.roseSoft,
  },
  secondaryActionButton: {
    flex: 1,
    minHeight: 52,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    borderWidth: 1,
    borderColor: palette.roseSoft,
    borderRadius: 16,
    backgroundColor: palette.surface,
  },
  secondaryActionButtonText: { color: palette.rose, fontSize: 14, fontWeight: "700" },
  inviteCodeCopy: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
    paddingHorizontal: 13,
    borderRadius: 14,
    backgroundColor: palette.roseSoft,
  },
  inviteCopyHint: { flexDirection: "row", alignItems: "center", gap: 5 },
  inviteCopyHintText: { color: palette.rose, fontSize: 11, fontWeight: "700" },
  personalizationHeading: { flexDirection: "row", alignItems: "center", gap: 7 },
  preferenceRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: palette.border,
  },
  preferenceCopy: { flex: 1 },
  personalizationLabel: {
    marginTop: 14,
    marginBottom: 8,
    color: palette.muted,
    fontSize: 11,
    fontWeight: "700",
  },
  optionRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  appearanceGrid: { gap: 8 },
  appearanceStyleOption: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 13,
    paddingVertical: 11,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 14,
    backgroundColor: palette.surface,
  },
  appearanceStyleCopy: { flex: 1, gap: 2 },
  appearanceStyleHint: { color: palette.muted, fontSize: 11 },
  appearanceOption: {
    minWidth: 72,
    minHeight: 38,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 12,
    backgroundColor: palette.surface,
  },
  appearanceOptionActive: {
    borderColor: palette.rose,
    backgroundColor: palette.roseSoft,
  },
  appearanceOptionText: { color: palette.ink, fontSize: 12, fontWeight: "700" },
  fontPreview: { color: palette.ink, fontSize: 17, fontWeight: "700" },
  themeDot: { width: 12, height: 12, borderRadius: 6 },
  themeGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  themeOption: { width: "30.7%", minHeight: 76, alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 8, borderWidth: 1, borderColor: palette.border, borderRadius: 15, backgroundColor: palette.surface },
  themePreview: { width: 38, height: 30, alignItems: "center", justifyContent: "center", overflow: "hidden", borderRadius: 10 },
  themePreviewSparkle: { position: "absolute", top: 0, right: 4, color: "#FFFFFF", fontSize: 12 },
  themePreviewLake: { position: "absolute", right: -4, bottom: 2, width: 26, height: 7, borderRadius: 9, backgroundColor: "#9DCFE3" },
  cardStylePreview: { width: 37, height: 27, gap: 4, justifyContent: "center", paddingHorizontal: 6, borderWidth: 1, borderColor: palette.border, borderRadius: 9, backgroundColor: palette.surface },
  cardStylePreviewSoft: { borderRadius: 14, shadowColor: palette.ink, shadowOpacity: 0.16, shadowRadius: 5, shadowOffset: { width: 0, height: 3 }, elevation: 2 },
  cardStylePreviewOutlined: { borderWidth: 2, borderColor: palette.rose, borderRadius: 4 },
  cardStylePreviewFlat: { borderWidth: 0, borderBottomWidth: 2, borderBottomColor: palette.rose, borderRadius: 0, backgroundColor: palette.roseSoft },
  cardStylePreviewLine: { height: 3, borderRadius: 3, backgroundColor: palette.rose },
  cardStylePreviewLineShort: { width: "62%", backgroundColor: palette.muted },
  navStylePreview: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 3, width: 39, height: 24, borderRadius: 10, backgroundColor: palette.roseSoft },
  navStylePreviewLine: { borderRadius: 0, borderTopWidth: 2, borderTopColor: palette.rose, backgroundColor: "transparent" },
  navStylePreviewMinimal: { width: 28, backgroundColor: "transparent" },
  navStylePreviewDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: palette.rose },
  emptyContent: {
    flexGrow: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 28,
    paddingVertical: 48,
  },
  emptyIllustration: {
    width: 104,
    height: 104,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 34,
    backgroundColor: palette.roseSoft,
  },
  emptyTitle: {
    marginTop: 25,
    color: palette.ink,
    fontSize: 28,
    fontWeight: "700",
  },
  emptyDescription: {
    maxWidth: 330,
    marginTop: 12,
    color: palette.muted,
    fontSize: 14,
    lineHeight: 23,
    textAlign: "center",
  },
  card: {
    marginBottom: 14,
    padding: 18,
    borderWidth: cardBorderWidth,
    borderColor: preferences.cardStyle === "outlined" ? palette.rose : palette.border,
    borderRadius: cardRadius,
    backgroundColor: preferences.cardStyle === "flat" ? "transparent" : palette.surface,
    ...(preferences.cardStyle === "soft" ? { shadowColor: palette.ink, shadowOpacity: 0.12, shadowRadius: 16, shadowOffset: { width: 0, height: 7 }, elevation: 4 } : {}),
  },
  heroCard: {
    marginBottom: 14,
    padding: 24,
    borderRadius: 25,
    backgroundColor: palette.burgundy,
  },
  heroEyebrow: { color: "#E8C9CA", fontSize: 12, letterSpacing: 1 },
  heroTitle: {
    marginTop: 12,
    color: "#FFFFFF",
    fontSize: 29,
    fontWeight: "700",
  },
  heroBody: { marginTop: 10, color: "#E7D6D1", fontSize: 14, lineHeight: 22 },
  heroFooter: {
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    marginTop: 24,
  },
  heroFooterText: { flex: 1, color: "#F8E9E5", fontSize: 12 },
  actionRow: {
    flexDirection: "row",
    alignItems: "stretch",
    gap: 10,
    marginBottom: 14,
  },
  actionButton: {
    flex: 1,
    minHeight: 52,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    borderRadius: 16,
    backgroundColor: palette.rose,
  },
  actionButtonText: { color: "#FFFFFF", fontSize: 14, fontWeight: "700" },
  inviteBadge: {
    justifyContent: "center",
    paddingHorizontal: 15,
    borderRadius: 16,
    backgroundColor: palette.roseSoft,
  },
  inviteBadgeLabel: { color: palette.muted, fontSize: 10 },
  inviteBadgeValue: {
    marginTop: 3,
    color: palette.rose,
    fontSize: 17,
    fontWeight: "800",
    letterSpacing: 1.5,
  },
  statRow: { flexDirection: "row", gap: 12, marginBottom: 14 },
  statCard: {
    flex: 1,
    padding: 15,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 19,
    backgroundColor: palette.surface,
  },
  statIcon: {
    width: 30,
    height: 30,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 9,
    borderRadius: 11,
    backgroundColor: palette.roseSoft,
  },
  statLabel: { color: palette.muted, fontSize: 12 },
  statValue: {
    marginTop: 7,
    color: palette.ink,
    fontSize: 18,
    fontWeight: "700",
  },
  balanceCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 14,
    padding: 18,
    borderRadius: 19,
    backgroundColor: palette.roseSoft,
  },
  balanceLabel: { color: palette.muted, fontSize: 12 },
  balanceValue: {
    marginTop: 7,
    color: palette.ink,
    fontSize: 23,
    fontWeight: "700",
  },
  trendText: {
    maxWidth: 130,
    color: palette.rose,
    fontSize: 12,
    lineHeight: 18,
    textAlign: "right",
  },
  donutLayout: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  donutWrap: {
    width: 172,
    height: 172,
    alignItems: "center",
    justifyContent: "center",
  },
  donutCenter: {
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
    maxWidth: 105,
  },
  donutCenterLabel: { color: palette.muted, fontSize: 11 },
  donutCenterValue: { marginTop: 4, color: palette.ink, fontSize: 13, fontWeight: "800" },
  donutLegend: { flex: 1, gap: 10 },
  donutLegendRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  donutLegendDot: { width: 9, height: 9, borderRadius: 5 },
  donutLegendName: { flex: 1, color: palette.ink, fontSize: 11 },
  donutLegendAmount: { color: palette.muted, fontSize: 10 },
  cardHeading: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 14,
  },
  cardTitle: { color: palette.ink, fontSize: 16, fontWeight: "700" },
  cardHint: { color: palette.muted, fontSize: 11 },
  travelPlanRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    minHeight: 64,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: palette.border,
  },
  travelPlanIcon: {
    width: 34,
    height: 34,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
    backgroundColor: palette.roseSoft,
  },
  settingsActionGrid: { gap: 9 },
  settingsActionButton: {
    minHeight: 46,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 13,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 14,
    backgroundColor: palette.background,
  },
  settingsActionText: { color: palette.ink, fontSize: 13, fontWeight: "600" },
  memberPaymentRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    minHeight: 54,
    borderBottomWidth: 1,
    borderBottomColor: "#F5ECE7",
  },
  avatar: {
    width: 34,
    height: 34,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
    backgroundColor: palette.roseSoft,
  },
  avatarText: { color: palette.rose, fontWeight: "800" },
  avatarSmall: {
    width: 30,
    height: 30,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 10,
    backgroundColor: palette.roseSoft,
  },
  avatarSmallText: { color: palette.rose, fontSize: 12, fontWeight: "800" },
  memberPaymentName: { flex: 1 },
  historyRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: palette.border,
  },
  historyIcon: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#EAF0EB",
  },
  historyAmount: {
    color: palette.ink,
    fontSize: 13,
    fontWeight: "700",
  },
  rowTitle: { color: palette.ink, fontSize: 13, fontWeight: "600" },
  rowSubtitle: {
    marginTop: 4,
    color: palette.muted,
    fontSize: 11,
    lineHeight: 17,
  },
  rowAmount: { color: palette.ink, fontSize: 13, fontWeight: "700" },
  incomeText: { color: palette.sage },
  insightCard: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 14,
    padding: 17,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 19,
    backgroundColor: palette.surface,
  },
  insightText: { flex: 1 },
  insightTitle: { color: palette.ink, fontSize: 14, fontWeight: "700" },
  insightBody: {
    marginTop: 5,
    color: palette.muted,
    fontSize: 12,
    lineHeight: 19,
  },
  settlementCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 14,
    padding: 17,
    borderRadius: 19,
    backgroundColor: "#FFF5F0",
  },
  settlementIcon: {
    width: 42,
    height: 42,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 15,
    backgroundColor: "#FFE3DB",
  },
  settlementText: { flex: 1 },
  settlementTitle: { color: palette.ink, fontSize: 14, fontWeight: "700" },
  settlementBody: {
    marginTop: 5,
    color: palette.muted,
    fontSize: 12,
    lineHeight: 18,
  },
  smallButton: {
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 11,
    backgroundColor: palette.rose,
  },
  smallButtonText: { color: "#FFFFFF", fontSize: 11, fontWeight: "700" },
  outlineButton: {
    minHeight: 44,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    marginTop: 16,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 13,
    backgroundColor: palette.surface,
  },
  outlineButtonText: { color: palette.rose, fontSize: 12, fontWeight: "700" },
  dangerButton: {
    minHeight: 44,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    marginTop: 14,
    borderWidth: 1,
    borderColor: "#EAC9C5",
    borderRadius: 13,
    backgroundColor: "#FFF4F0",
  },
  dangerButtonText: { color: palette.rose, fontSize: 12, fontWeight: "700" },
  transactionRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    minHeight: 60,
    borderBottomWidth: 1,
    borderBottomColor: "#F5ECE7",
  },
  transactionIcon: {
    width: 38,
    height: 38,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 13,
  },
  barRow: { marginBottom: 15 },
  barLabelRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 8,
  },
  barTrack: {
    height: 8,
    marginTop: 8,
    overflow: "hidden",
    borderRadius: 5,
    backgroundColor: "#F2E8E3",
  },
  barFill: { height: 8, borderRadius: 5 },
  compareRow: { marginTop: 14, gap: 10 },
  compareItem: { flexDirection: "row", alignItems: "center", gap: 8 },
  compareSwatch: { width: 10, height: 10, borderRadius: 5 },
  progressTrack: {
    height: 10,
    marginTop: 4,
    overflow: "hidden",
    borderRadius: 6,
    backgroundColor: "#F2E8E3",
  },
  progressFill: { height: 10, borderRadius: 6 },
  progressHint: { marginTop: 8, color: palette.muted, fontSize: 11 },
  warningText: { color: "#B4575D" },
  budgetRow: { marginBottom: 15 },
  recurringRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    minHeight: 58,
    borderBottomWidth: 1,
    borderBottomColor: "#F5ECE7",
  },
  recurringIcon: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
    backgroundColor: palette.roseSoft,
  },
  outlineIconButton: {
    width: 34,
    height: 34,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#E3C3C4",
    borderRadius: 11,
  },
  dashedButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    minHeight: 44,
    marginTop: 10,
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: "#D9B9B5",
    borderRadius: 13,
  },
  dashedButtonText: { color: palette.rose, fontSize: 13, fontWeight: "700" },
  emptyInline: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 13,
  },
  emptyInlineText: {
    flex: 1,
    color: palette.muted,
    fontSize: 12,
    lineHeight: 18,
  },
  inviteCodeLarge: {
    marginVertical: 9,
    color: palette.rose,
    fontSize: 30,
    fontWeight: "900",
    letterSpacing: 4,
  },
  qrWrap: {
    alignItems: "center",
    marginTop: 16,
    padding: 16,
    borderRadius: 16,
    backgroundColor: "#FFFFFF",
  },
  qrCaption: {
    marginTop: 12,
    color: palette.muted,
    fontSize: 10,
    textAlign: "center",
  },
  rolePill: {
    paddingHorizontal: 9,
    paddingVertical: 7,
    borderRadius: 10,
    backgroundColor: palette.roseSoft,
  },
  rolePillText: { color: palette.rose, fontSize: 10, fontWeight: "700" },
  settingsPillRow: { gap: 8, paddingTop: 12, paddingBottom: 2 },
  settingsFilterRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8, marginBottom: 10 },
  settingsFilterActions: { flex: 1, flexDirection: "row", justifyContent: "flex-end", flexWrap: "wrap", gap: 6 },
  settingsFilterButton: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 6, borderRadius: 10, backgroundColor: palette.roseSoft },
  settingsFilterText: { color: palette.rose, fontSize: 11, fontWeight: "700" },
  settingsList: { gap: 7 },
  settingsListRow: { minHeight: 54, flexDirection: "row", alignItems: "center", gap: 9, paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: palette.border },
  settingsListIcon: { width: 34, height: 34, alignItems: "center", justifyContent: "center", borderRadius: 11, backgroundColor: palette.roseSoft },
  settingsListIconText: { color: palette.rose, fontSize: 17 },
  compactListToggle: { minHeight: 40, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, marginTop: 3, borderWidth: 1, borderColor: palette.roseSoft, borderRadius: 12, backgroundColor: palette.surface },
  compactListToggleText: { color: palette.rose, fontSize: 12, fontWeight: "700" },
  settingsRemovePill: { paddingHorizontal: 10, paddingVertical: 8, borderRadius: 11, backgroundColor: "#FFF4F0", borderWidth: 1, borderColor: "#EAC9C5" },
  settingsRemovePillText: { color: palette.rose, fontSize: 11, fontWeight: "700" },
  activityLogScroll: { maxHeight: 250 },
  activityLogRow: { flexDirection: "row", alignItems: "center", gap: 10, minHeight: 54, borderBottomWidth: 1, borderBottomColor: "#F5ECE7" },
  activityLogDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: palette.rose },
  weekRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 7,
  },
  weekLabel: {
    width: "14.28%",
    color: palette.muted,
    fontSize: 11,
    textAlign: "center",
  },
  calendarGrid: { flexDirection: "row", flexWrap: "wrap" },
  calendarCell: {
    width: "14.28%",
    height: 47,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
  },
  calendarSelected: { backgroundColor: palette.roseSoft },
  calendarDay: { color: palette.ink, fontSize: 13 },
  calendarDaySelected: { color: palette.rose, fontWeight: "800" },
  calendarDot: { width: 5, height: 5, marginTop: 4, borderRadius: 3 },
  paymentOverviewScroll: { maxHeight: 170 },
  recentTransactionsScroll: { maxHeight: 286 },
  transactionActions: { flexDirection: "row", alignItems: "center", gap: 3, marginLeft: 6 },
  rowActionButton: { width: 28, height: 28, alignItems: "center", justifyContent: "center", borderRadius: 9, backgroundColor: "#FBF3EF" },
  receiptActions: { flexDirection: "row", gap: 8, marginBottom: 14 },
  receiptButton: { flex: 1, minHeight: 42, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, borderWidth: 1, borderColor: "#E3C3C4", borderRadius: 12, backgroundColor: "#FFF9F6" },
  receiptButtonText: { color: palette.rose, fontSize: 11, fontWeight: "700" },
  datePickerTrigger: { minHeight: 48, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 14, borderWidth: 1, borderColor: palette.border, borderRadius: 13, backgroundColor: palette.surface },
  datePickerValueRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  datePickerText: { color: palette.ink, fontSize: 14, fontWeight: "700" },
  calendarOverlay: { flex: 1, alignItems: "center", justifyContent: "center", padding: 20, backgroundColor: "rgba(58,47,43,0.32)" },
  dateCalendarCard: { width: "100%", maxWidth: 360, padding: 18, borderRadius: 22, backgroundColor: palette.surface },
  calendarHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 14 },
  calendarArrow: { width: 36, height: 36, alignItems: "center", justifyContent: "center", borderRadius: 12, backgroundColor: palette.roseSoft },
  calendarMonthTitle: { color: palette.ink, fontSize: 16, fontWeight: "800" },
  calendarWeekRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 6 },
  calendarWeekday: { width: "14.28%", color: palette.muted, fontSize: 11, textAlign: "center" },
  calendarDayCell: { width: "14.28%", height: 42, alignItems: "center", justifyContent: "center", borderRadius: 12 },
  calendarDayActive: { backgroundColor: palette.rose },
  calendarDayText: { color: palette.ink, fontSize: 13, fontWeight: "600" },
  calendarDayTextActive: { color: "#FFFFFF", fontWeight: "800" },
  smallMark: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
    backgroundColor: palette.roseSoft,
  },
  confirmOverlay: { flex: 1, alignItems: "center", justifyContent: "center", padding: 22, backgroundColor: "rgba(58,47,43,0.34)" },
  confirmDismiss: { ...StyleSheet.absoluteFillObject },
  confirmCard: { width: "100%", maxWidth: 380, borderWidth: 1, borderRadius: 26, padding: 22, shadowColor: "#3A2F2B", shadowOpacity: 0.18, shadowRadius: 24, shadowOffset: { width: 0, height: 10 }, elevation: 8 },
  confirmIcon: { width: 48, height: 48, alignItems: "center", justifyContent: "center", borderRadius: 16, marginBottom: 15 },
  confirmTitle: { color: palette.ink, fontSize: 18, fontWeight: "800" },
  confirmMessage: { marginTop: 8, color: palette.muted, fontSize: 13, lineHeight: 20 },
  confirmActions: { flexDirection: "row", gap: 10, marginTop: 22 },
  confirmCancel: { flex: 1, minHeight: 46, alignItems: "center", justifyContent: "center", borderWidth: 1, borderRadius: 14 },
  confirmCancelLink: { alignItems: "center", justifyContent: "center", minHeight: 42, marginTop: 6 },
  confirmCancelText: { fontSize: 13, fontWeight: "700" },
  confirmPrimary: { flex: 1, minHeight: 46, alignItems: "center", justifyContent: "center", borderRadius: 14 },
  confirmPrimaryText: { color: "#FFFFFF", fontSize: 13, fontWeight: "800" },
  confirmOptionList: { gap: 9, marginTop: 20 },
  confirmOption: { minHeight: 50, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 13, borderWidth: 1, borderRadius: 14 },
  confirmOptionText: { flex: 1, fontSize: 13, fontWeight: "700" },
  modalBackdrop: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(58,47,43,0.28)",
  },
  modalDismiss: { flex: 1 },
  modalScroll: { maxHeight: "90%" },
  modalCard: {
    paddingHorizontal: 22,
    paddingTop: 12,
    paddingBottom: 30,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    backgroundColor: palette.surface,
  },
  modalHandle: {
    alignSelf: "center",
    width: 44,
    height: 5,
    borderRadius: 3,
    backgroundColor: "#E4D6CF",
  },
  modalTitle: {
    marginTop: 22,
    color: palette.ink,
    fontSize: 22,
    fontWeight: "700",
  },
  modalDescription: {
    marginTop: 8,
    marginBottom: 18,
    color: palette.muted,
    fontSize: 13,
    lineHeight: 20,
  },
  input: {
    minHeight: 52,
    marginBottom: 14,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 14,
    backgroundColor: "#FFFAF7",
    color: palette.ink,
    fontSize: 15,
  },
  textarea: { minHeight: 80, paddingTop: 14, textAlignVertical: "top" },
  field: { marginBottom: 14 },
  fieldLabel: {
    marginBottom: 8,
    color: palette.ink,
    fontSize: 12,
    fontWeight: "700",
  },
  optionScroller: { gap: 8, paddingBottom: 4 },
  optionChip: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 12,
    backgroundColor: palette.surface,
  },
  optionChipActive: {
    borderColor: palette.rose,
    backgroundColor: palette.roseSoft,
  },
  optionChipText: { color: palette.muted, fontSize: 12 },
  optionChipTextActive: { color: palette.rose, fontWeight: "700" },
  segmentRow: { flexDirection: "row", gap: 8, marginBottom: 14 },
  segment: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 12,
  },
  segmentActive: { borderColor: palette.rose, backgroundColor: palette.roseSoft },
  segmentText: { color: palette.muted, fontSize: 12, fontWeight: "600" },
  segmentTextActive: { color: palette.rose },
  miniSegment: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 11,
  },
  miniSegmentActive: {
    borderColor: palette.rose,
    backgroundColor: palette.roseSoft,
  },
  miniSegmentText: { color: palette.muted, fontSize: 11 },
  miniSegmentTextActive: { color: palette.rose, fontWeight: "700" },
  splitInputRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 8,
  },
  splitInput: {
    width: 130,
    minHeight: 42,
    paddingHorizontal: 11,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 11,
    backgroundColor: "#FFFAF7",
    color: palette.ink,
  },
  primaryButton: {
    minHeight: 52,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 16,
    backgroundColor: palette.rose,
  },
  primaryButtonText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "700",
    letterSpacing: 0.5,
  },
  secondaryButton: {
    minHeight: 52,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    marginTop: 12,
    borderWidth: 1,
    borderColor: "#E3C3C4",
    borderRadius: 16,
    backgroundColor: palette.surface,
  },
  secondaryButtonText: { color: palette.rose, fontSize: 15, fontWeight: "700" },
  setupNotice: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    marginBottom: 14,
    padding: 12,
    borderRadius: 13,
    backgroundColor: palette.roseSoft,
  },
  setupNoticeCopy: {
    flex: 1,
  },
  setupNoticeTitle: {
    color: palette.ink,
    fontSize: 12,
    fontWeight: "800",
  },
  setupNoticeBody: {
    marginTop: 3,
    color: palette.muted,
    fontSize: 11,
    lineHeight: 16,
  },
  setupNoticeButton: {
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 10,
    backgroundColor: palette.surface,
  },
  setupNoticeButtonText: {
    color: palette.rose,
    fontSize: 12,
    fontWeight: "800",
  },
  errorText: {
    marginBottom: 14,
    color: "#B4575D",
    fontSize: 12,
    lineHeight: 18,
  },
  modalCancel: { alignItems: "center", paddingVertical: 15 },
  modalCancelText: { color: palette.muted, fontSize: 14 },
  modalOptionList: { gap: 8 },
  modalOptionRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    minHeight: 54,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: palette.border,
    borderRadius: 14,
    backgroundColor: palette.background,
  },
  emptyText: { color: palette.muted, fontSize: 13, lineHeight: 20 },
  multilineInput: { minHeight: 80, textAlignVertical: "top" },
  pressed: { opacity: 0.82, transform: [{ scale: 0.98 }] },
  disabled: { opacity: 0.58 },
  });
};

let styles = createStyles(colors, appearanceDefaults);
